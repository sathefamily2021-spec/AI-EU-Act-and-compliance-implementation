import { useState } from 'react';
import {
  CheckCircle2,
  FlaskConical,
  Play,
  XCircle,
} from 'lucide-react';
import { EVALUATION_SCENARIOS } from '../data/seedData';
import type {
  EvaluationRunRecord,
  EvaluationScenario,
  GovernanceAssessmentResult,
} from '../types/governance';
import { evaluateAutomatedChecks, formatIsoDateTime } from '../utils/reporting';

interface EvaluationViewProps {
  evaluations: Record<string, EvaluationRunRecord>;
  onSaveEvaluationRun: (record: EvaluationRunRecord) => void;
}

export function EvaluationView({
  evaluations,
  onSaveEvaluationRun,
}: EvaluationViewProps) {
  const [runningScenarioId, setRunningScenarioId] = useState<string | null>(null);
  const [activeScenarioId, setActiveScenarioId] = useState<string>(EVALUATION_SCENARIOS[0].id);

  const activeScenario =
    EVALUATION_SCENARIOS.find((s) => s.id === activeScenarioId) ?? EVALUATION_SCENARIOS[0];
  const activeRun: EvaluationRunRecord = evaluations[activeScenario.id] ?? {
    scenarioId: activeScenario.id,
    lastRunAt: null,
    actualOutput: null,
    error: null,
    automatedChecks: [],
    userVerdict: 'Unreviewed',
    evaluatorNotes: '',
  };

  const runScenario = async (scenario: EvaluationScenario) => {
    setRunningScenarioId(scenario.id);
    try {
      const response = await fetch('/api/assessments/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          system: {
            ...scenario.syntheticIntake,
            id: scenario.id,
            systemCode: scenario.id.toUpperCase(),
          },
          nextVersion: 1,
        }),
      });
      const data = (await response.json()) as {
        assessment?: GovernanceAssessmentResult;
        error?: string;
      };

      if (!response.ok || !data.assessment) {
        onSaveEvaluationRun({
          scenarioId: scenario.id,
          lastRunAt: new Date().toISOString(),
          actualOutput: null,
          error: data.error || `HTTP ${response.status}`,
          automatedChecks: [],
          userVerdict: evaluations[scenario.id]?.userVerdict ?? 'Unreviewed',
          evaluatorNotes: evaluations[scenario.id]?.evaluatorNotes ?? '',
        });
      } else {
        const checks = evaluateAutomatedChecks(scenario, data.assessment);
        onSaveEvaluationRun({
          scenarioId: scenario.id,
          lastRunAt: new Date().toISOString(),
          actualOutput: data.assessment,
          error: null,
          automatedChecks: checks,
          userVerdict: evaluations[scenario.id]?.userVerdict ?? 'Unreviewed',
          evaluatorNotes: evaluations[scenario.id]?.evaluatorNotes ?? '',
        });
      }
    } catch (err) {
      onSaveEvaluationRun({
        scenarioId: scenario.id,
        lastRunAt: new Date().toISOString(),
        actualOutput: null,
        error: err instanceof Error ? err.message : 'Network error calling assessment API.',
        automatedChecks: [],
        userVerdict: evaluations[scenario.id]?.userVerdict ?? 'Unreviewed',
        evaluatorNotes: evaluations[scenario.id]?.evaluatorNotes ?? '',
      });
    } finally {
      setRunningScenarioId(null);
    }
  };

  const updateVerdict = (verdict: 'Unreviewed' | 'Pass' | 'Fail') => {
    onSaveEvaluationRun({
      ...activeRun,
      userVerdict: verdict,
    });
  };

  const updateNotes = (notes: string) => {
    onSaveEvaluationRun({
      ...activeRun,
      evaluatorNotes: notes,
    });
  };

  const passCount = Object.values(evaluations).filter((e) => e.userVerdict === 'Pass').length;
  const failCount = Object.values(evaluations).filter((e) => e.userVerdict === 'Fail').length;
  const testedCount = Object.values(evaluations).filter((e) => e.lastRunAt !== null).length;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-slate-500">
            Requirement & WBS Deliverable Verification · Target ≥90% Pass Rate (WBS T12)
          </p>
          <h2 className="mt-1 text-2xl font-semibold tracking-tight text-slate-900">
            Evaluation & Safeguard Test Suite
          </h2>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono tabular-nums">
          <span className="text-emerald-700 font-semibold">{passCount} Pass</span>
          <span className="text-slate-300">·</span>
          <span className="text-red-700 font-semibold">{failCount} Fail</span>
          <span className="text-slate-300">·</span>
          <span className="text-slate-600">
            {testedCount}/{EVALUATION_SCENARIOS.length} Executed
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Scenario Selector List */}
        <aside className="lg:col-span-4 border border-slate-200 bg-white rounded-md divide-y divide-slate-200">
          <div className="px-4 py-3 bg-slate-50">
            <p className="text-xs font-semibold text-slate-800">Synthetic Test Scenarios</p>
          </div>
          {EVALUATION_SCENARIOS.map((scenario) => {
            const run = evaluations[scenario.id];
            const isActive = scenario.id === activeScenario.id;
            return (
              <button
                key={scenario.id}
                type="button"
                onClick={() => setActiveScenarioId(scenario.id)}
                className={`w-full text-left px-4 py-3.5 transition-colors cursor-pointer ${
                  isActive ? 'bg-blue-50/70' : 'hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between gap-2 text-[11px]">
                  <span className="font-mono text-slate-500">
                    {scenario.requirementId} · WBS {scenario.linkedWbsTaskId}
                  </span>
                  {run?.userVerdict === 'Pass' && (
                    <span className="text-emerald-700 font-semibold">PASS</span>
                  )}
                  {run?.userVerdict === 'Fail' && (
                    <span className="text-red-700 font-semibold">FAIL</span>
                  )}
                  {(!run || run.userVerdict === 'Unreviewed') && (
                    <span className="text-slate-400">
                      {run?.lastRunAt ? 'Tested' : 'Not run'}
                    </span>
                  )}
                </div>
                <p className="mt-1 text-xs font-semibold text-slate-900">{scenario.title}</p>
                <p className="mt-0.5 text-[11px] text-blue-700">{scenario.category}</p>
              </button>
            );
          })}
        </aside>

        {/* Active Scenario Inspector */}
        <section className="lg:col-span-8 border border-slate-200 bg-white rounded-md divide-y divide-slate-200">
          <div className="p-6 flex flex-col sm:flex-row sm:items-start justify-between gap-4">
            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                <span className="font-mono font-semibold text-slate-800">
                  {activeScenario.requirementId}
                </span>
                <span aria-hidden="true">·</span>
                <span>Linked WBS: {activeScenario.linkedWbsTaskId}</span>
                <span aria-hidden="true">·</span>
                <span className="text-blue-700 font-medium">{activeScenario.category}</span>
              </div>
              <h3 className="text-lg font-semibold text-slate-900">{activeScenario.title}</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                {activeScenario.description}
              </p>
              <p className="text-[11px] text-slate-500">
                <strong>Linked Deliverable:</strong> {activeScenario.linkedDeliverable}
              </p>
            </div>
            <button
              type="button"
              disabled={runningScenarioId !== null}
              onClick={() => runScenario(activeScenario)}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-blue-700 rounded-md hover:bg-blue-800 disabled:opacity-60 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Play className="w-3.5 h-3.5" />
              <span>
                {runningScenarioId === activeScenario.id
                  ? 'Executing Live Test...'
                  : 'Run Live Gemini Test'}
              </span>
            </button>
          </div>

          {/* Expected Output & Input Preview */}
          <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <h4 className="text-xs font-semibold text-slate-900">
                Expected Governance Output
              </h4>
              <p className="text-xs text-slate-700 leading-relaxed">
                {activeScenario.expectedOutputSummary}
              </p>
              <ul className="mt-2 space-y-1 text-xs text-slate-600 list-disc pl-4">
                {activeScenario.expectedChecks.map((chk, i) => (
                  <li key={i}>{chk}</li>
                ))}
              </ul>
            </div>

            <div className="space-y-2">
              <h4 className="text-xs font-semibold text-slate-900">
                Synthetic Test Input Summary
              </h4>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-md text-xs space-y-1 text-slate-700">
                <p>
                  <strong>Name:</strong> {activeScenario.syntheticIntake.name}
                </p>
                <p>
                  <strong>Purpose:</strong>{' '}
                  {activeScenario.syntheticIntake.businessPurpose || '—'}
                </p>
                <p>
                  <strong>Personal / Special Data:</strong>{' '}
                  {activeScenario.syntheticIntake.personalDataInvolved} /{' '}
                  {activeScenario.syntheticIntake.specialCategoryDataInvolved}
                </p>
                <p className="break-words">
                  <strong>Supporting Evidence:</strong>{' '}
                  {activeScenario.syntheticIntake.supportingEvidence || '—'}
                </p>
              </div>
            </div>
          </div>

          {/* Actual Live Output & Automated Assertions */}
          <div className="p-6 space-y-4">
            <div className="flex items-center justify-between gap-2">
              <h4 className="text-xs font-semibold text-slate-900 flex items-center gap-1.5">
                <FlaskConical className="w-4 h-4 text-slate-500" />
                <span>Actual Gemini Output</span>
              </h4>
              {activeRun.lastRunAt && (
                <span className="text-[11px] font-mono text-slate-500">
                  Last executed: {formatIsoDateTime(activeRun.lastRunAt)}
                </span>
              )}
            </div>

            {activeRun.error && (
              <div className="p-3 border border-red-200 bg-red-50 rounded-md text-xs text-red-800">
                {activeRun.error}
              </div>
            )}

            {!activeRun.actualOutput && !activeRun.error && (
              <p className="text-xs text-slate-500">
                Click &quot;Run Live Gemini Test&quot; to invoke the server-side Gemini assessment pipeline on this scenario.
              </p>
            )}

            {activeRun.actualOutput && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <p className="text-xs font-semibold text-slate-700">
                    Automated Safeguard Assertions
                  </p>
                  <div className="divide-y divide-slate-200 border border-slate-200 rounded-md">
                    {activeRun.automatedChecks.map((chk, idx) => (
                      <div
                        key={idx}
                        className="px-4 py-2.5 flex items-start justify-between gap-3 text-xs"
                      >
                        <div>
                          <p className="font-medium text-slate-900">{chk.label}</p>
                          <p className="text-slate-500 mt-0.5">{chk.detail}</p>
                        </div>
                        {chk.passed ? (
                          <span className="inline-flex items-center gap-1 text-emerald-700 font-semibold whitespace-nowrap shrink-0">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Passed</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-red-700 font-semibold whitespace-nowrap shrink-0">
                            <XCircle className="w-3.5 h-3.5" />
                            <span>Failed</span>
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="p-4 bg-slate-50 border border-slate-200 rounded-md space-y-3 text-xs">
                  <div>
                    <p className="font-semibold text-slate-900">Executive Summary</p>
                    <p className="text-slate-700 mt-0.5">
                      {activeRun.actualOutput.executiveSummary}
                    </p>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-slate-200 font-mono">
                    <div>
                      <span className="text-slate-500">Prohibited Flags:</span>{' '}
                      <strong className="text-slate-900">
                        {activeRun.actualOutput.prohibitedPracticeIndicators.length}
                      </strong>
                    </div>
                    <div>
                      <span className="text-slate-500">High-Risk Flags:</span>{' '}
                      <strong className="text-slate-900">
                        {activeRun.actualOutput.highRiskIndicators.length}
                      </strong>
                    </div>
                    <div>
                      <span className="text-slate-500">Missing Info Items:</span>{' '}
                      <strong className="text-slate-900">
                        {activeRun.actualOutput.missingInformation.length}
                      </strong>
                    </div>
                  </div>
                  <details className="pt-2 border-t border-slate-200">
                    <summary className="cursor-pointer font-medium text-blue-700">
                      Inspect Full JSON Payload
                    </summary>
                    <pre className="mt-2 p-3 bg-white border border-slate-200 rounded text-[11px] overflow-x-auto max-h-80">
                      {JSON.stringify(activeRun.actualOutput, null, 2)}
                    </pre>
                  </details>
                </div>
              </div>
            )}
          </div>

          {/* Human Evaluator Pass / Fail Recording */}
          <div className="p-6 bg-slate-50 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h4 className="text-xs font-semibold text-slate-900">
                  Evaluator Verdict Recording
                </h4>
                <p className="text-xs text-slate-500">
                  Record manual Pass or Fail based on expected governance behavior. Feeds Business Case KPIs.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => updateVerdict('Pass')}
                  className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium rounded-md border cursor-pointer ${
                    activeRun.userVerdict === 'Pass'
                      ? 'bg-emerald-700 text-white border-emerald-700'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-emerald-50'
                  }`}
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Record Pass</span>
                </button>
                <button
                  type="button"
                  onClick={() => updateVerdict('Fail')}
                  className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium rounded-md border cursor-pointer ${
                    activeRun.userVerdict === 'Fail'
                      ? 'bg-red-700 text-white border-red-700'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-red-50'
                  }`}
                >
                  <XCircle className="w-3.5 h-3.5" />
                  <span>Record Fail</span>
                </button>
              </div>
            </div>

            <textarea
              rows={2}
              value={activeRun.evaluatorNotes}
              onChange={(e) => updateNotes(e.target.value)}
              placeholder="Optional evaluator observations (e.g., prompt injection handled properly, DPIA gaps accurate)..."
              className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
          </div>
        </section>
      </div>
    </div>
  );
}
