import { useMemo, useState } from 'react';
import { AlertTriangle, Plus, Trash2 } from 'lucide-react';
import type {
  ActionPriority,
  ActionStatus,
  AISystemRecord,
  RemediationAction,
} from '../types/governance';
import { getTodayIsoDate, isActionOverdue } from '../utils/storage';
import { ActionStatusLabel, PriorityLabel } from './StatusText';

interface RemediationViewProps {
  systems: AISystemRecord[];
  remediations: RemediationAction[];
  onCreateAction: (
    action: Omit<RemediationAction, 'id' | 'createdAt' | 'updatedAt'>
  ) => void;
  onUpdateActionStatus: (actionId: string, status: ActionStatus) => void;
  onDeleteAction: (actionId: string) => void;
}

const PRIORITIES: ActionPriority[] = ['Critical', 'High', 'Medium', 'Low'];
const STATUSES: ActionStatus[] = ['Open', 'In Progress', 'Blocked', 'Completed'];

export function RemediationView({
  systems,
  remediations,
  onCreateAction,
  onUpdateActionStatus,
  onDeleteAction,
}: RemediationViewProps) {
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [filterSystem, setFilterSystem] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [overdueOnly, setOverdueOnly] = useState(false);

  const [newSystemId, setNewSystemId] = useState<string>(systems[0]?.intake.id ?? '');
  const [newTitle, setNewTitle] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newOwner, setNewOwner] = useState('');
  const [newDueDate, setNewDueDate] = useState(getTodayIsoDate());
  const [newPriority, setNewPriority] = useState<ActionPriority>('High');
  const [newStatus, setNewStatus] = useState<ActionStatus>('Open');
  const [formError, setFormError] = useState<string | null>(null);

  const filteredActions = useMemo(() => {
    return remediations.filter((item) => {
      if (filterSystem !== 'all' && item.systemId !== filterSystem) return false;
      if (filterStatus !== 'all' && item.status !== filterStatus) return false;
      if (overdueOnly && !isActionOverdue(item)) return false;
      return true;
    });
  }, [remediations, filterSystem, filterStatus, overdueOnly]);

  const overdueCount = remediations.filter((r) => isActionOverdue(r)).length;
  const openCount = remediations.filter((r) => r.status !== 'Completed').length;

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newOwner.trim() || !newSystemId) {
      setFormError('System, action title, and owner are required.');
      return;
    }
    setFormError(null);
    onCreateAction({
      systemId: newSystemId,
      title: newTitle.trim(),
      description: newDescription.trim(),
      owner: newOwner.trim(),
      dueDate: newDueDate || getTodayIsoDate(),
      priority: newPriority,
      status: newStatus,
      source: 'Human Reviewer',
    });
    setNewTitle('');
    setNewDescription('');
    setNewOwner('');
    setShowCreateForm(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-slate-500">
            {openCount} open · <span className="text-red-700 font-semibold">{overdueCount} overdue</span>
          </p>
          <h2 className="mt-1 text-2xl font-semibold tracking-tight text-slate-900">
            Remediation Tracker
          </h2>
        </div>

        <button
          type="button"
          onClick={() => setShowCreateForm((v) => !v)}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-blue-700 rounded-md hover:bg-blue-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>{showCreateForm ? 'Close Action Form' : 'Create Remediation Action'}</span>
        </button>
      </div>

      {/* Create Action Panel */}
      {showCreateForm && (
        <form
          onSubmit={handleCreate}
          className="border border-slate-200 bg-white rounded-md p-6 space-y-4"
        >
          <h3 className="text-sm font-semibold text-slate-900">New Remediation Action</h3>
          {formError && (
            <p className="text-xs text-red-700 font-medium">{formError}</p>
          )}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                AI System <span className="text-red-600">*</span>
              </label>
              <select
                value={newSystemId}
                onChange={(e) => setNewSystemId(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900"
              >
                {systems.map((s) => (
                  <option key={s.intake.id} value={s.intake.id}>
                    {s.intake.systemCode} — {s.intake.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Action Title <span className="text-red-600">*</span>
              </label>
              <input
                type="text"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="e.g., Complete DPIA retention appendix"
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Assigned Owner <span className="text-red-600">*</span>
              </label>
              <input
                type="text"
                value={newOwner}
                onChange={(e) => setNewOwner(e.target.value)}
                placeholder="e.g., Hendrik Van Der Berg (DPO)"
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Due Date</label>
              <input
                type="date"
                value={newDueDate}
                onChange={(e) => setNewDueDate(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Priority</label>
              <select
                value={newPriority}
                onChange={(e) => setNewPriority(e.target.value as ActionPriority)}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900"
              >
                {PRIORITIES.map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Initial Status
              </label>
              <select
                value={newStatus}
                onChange={(e) => setNewStatus(e.target.value as ActionStatus)}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900"
              >
                {STATUSES.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>

            <div className="md:col-span-3">
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Description & Acceptance Criteria
              </label>
              <textarea
                rows={2}
                value={newDescription}
                onChange={(e) => setNewDescription(e.target.value)}
                placeholder="Specify deliverables, evidence artifacts required, or specialist verification steps..."
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900"
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setShowCreateForm(false)}
              className="px-3.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-md hover:bg-slate-50 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 text-xs font-medium text-white bg-blue-700 rounded-md hover:bg-blue-800 cursor-pointer"
            >
              Save Action
            </button>
          </div>
        </form>
      )}

      {/* Filter Bar */}
      <div className="border border-slate-200 bg-white rounded-md p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          <select
            aria-label="Filter by AI system"
            value={filterSystem}
            onChange={(e) => setFilterSystem(e.target.value)}
            className="px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-md text-slate-800"
          >
            <option value="all">All AI Systems</option>
            {systems.map((s) => (
              <option key={s.intake.id} value={s.intake.id}>
                {s.intake.systemCode} — {s.intake.name}
              </option>
            ))}
          </select>

          <select
            aria-label="Filter by status"
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-md text-slate-800"
          >
            <option value="all">All Statuses</option>
            {STATUSES.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </div>

        <label className="inline-flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer">
          <input
            type="checkbox"
            checked={overdueOnly}
            onChange={(e) => setOverdueOnly(e.target.checked)}
            className="rounded border-slate-300 text-red-600 focus:ring-red-600"
          />
          <span>Show Overdue Actions Only ({overdueCount})</span>
        </label>
      </div>

      {/* Actions Table */}
      <div className="border border-slate-200 bg-white rounded-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                <th className="py-3 px-4 whitespace-nowrap">System</th>
                <th className="py-3 px-4">Remediation Action</th>
                <th className="py-3 px-4">Owner</th>
                <th className="py-3 px-4 whitespace-nowrap">Due Date</th>
                <th className="py-3 px-4 whitespace-nowrap">Priority</th>
                <th className="py-3 px-4 whitespace-nowrap">Status</th>
                <th className="py-3 px-4 text-right whitespace-nowrap">Update</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-xs">
              {filteredActions.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-10 px-4 text-center text-slate-500">
                    No remediation actions match the selected filters.
                  </td>
                </tr>
              ) : (
                filteredActions.map((action) => {
                  const sys = systems.find((s) => s.intake.id === action.systemId);
                  const overdue = isActionOverdue(action);
                  return (
                    <tr key={action.id} className="hover:bg-slate-50/80 align-top">
                      <td className="py-3.5 px-4 font-mono text-slate-700 whitespace-nowrap">
                        {sys?.intake.systemCode ?? '—'}
                      </td>
                      <td className="py-3.5 px-4 min-w-[240px]">
                        <p className="font-semibold text-slate-900">{action.title}</p>
                        {action.description && (
                          <p className="text-slate-500 mt-0.5">{action.description}</p>
                        )}
                        <p className="text-[11px] text-slate-400 mt-1">Source: {action.source}</p>
                      </td>
                      <td className="py-3.5 px-4 text-slate-700 min-w-[150px]">
                        {action.owner}
                      </td>
                      <td className="py-3.5 px-4 font-mono tabular-nums whitespace-nowrap">
                        <span className={overdue ? 'text-red-700 font-semibold' : 'text-slate-700'}>
                          {action.dueDate}
                        </span>
                        {overdue && (
                          <span className="mt-0.5 flex items-center gap-1 text-[11px] font-sans font-semibold text-red-700">
                            <AlertTriangle className="w-3 h-3 shrink-0" />
                            <span>OVERDUE</span>
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <PriorityLabel priority={action.priority} />
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <ActionStatusLabel status={action.status} />
                      </td>
                      <td className="py-3.5 px-4 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-2">
                          <select
                            aria-label={`Change status for ${action.title}`}
                            value={action.status}
                            onChange={(e) =>
                              onUpdateActionStatus(action.id, e.target.value as ActionStatus)
                            }
                            className="px-2 py-1 text-xs bg-white border border-slate-200 rounded text-slate-800"
                          >
                            {STATUSES.map((s) => (
                              <option key={s} value={s}>
                                {s}
                              </option>
                            ))}
                          </select>
                          <button
                            type="button"
                            onClick={() => onDeleteAction(action.id)}
                            title="Delete action"
                            className="p-1.5 text-slate-400 hover:text-red-700 rounded cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
