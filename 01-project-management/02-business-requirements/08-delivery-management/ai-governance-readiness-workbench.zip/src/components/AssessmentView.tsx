import { useState } from 'react';
import {
  AlertTriangle,
  Check,
  Download,
  FileText,
  Play,
  Plus,
  ShieldAlert,
  ShieldCheck,
  UserCheck,
} from 'lucide-react';
import type {
  AISystemRecord,
  HistoryEntry,
  RecommendedActionSuggestion,
  RemediationAction,
} from '../types/governance';
import {
  downloadTextFile,
  formatIsoDateTime,
  generateSystemReportMarkdown,
} from '../utils/reporting';
import { ReviewStatusLabel } from './StatusText';

interface AssessmentViewProps {
  systems: AISystemRecord[];
  remediations: RemediationAction[];
  history: HistoryEntry[];
  organisationName: string;
  selectedSystemId: string | null;
  onSelectSystem: (id: string) => void;
  onRunAssessment: (systemId: string) => Promise<void>;
  isAssessing: boolean;
  assessmentError: string | null;
  onAddRemediationFromSuggestion: (
    systemId: string,
    suggestion: RecommendedActionSuggestion
  ) => void;
  onNavigate: (tab: string, systemId?: string) => void;
}

export function AssessmentView({
  systems,
  remediations,
  history,
  organisationName,
  selectedSystemId,
  onSelectSystem,
  onRunAssessment,
  isAssessing,
  assessmentError,
  onAddRemediationFromSuggestion,
  onNavigate,
}: AssessmentViewProps) {
  const activeSystem =
    systems.find((s) => s.intake.id === selectedSystemId) ?? systems[0] ?? null;
  const [addedTitles, setAddedTitles] = useState<Record<string, boolean>>({});

  if (!activeSystem) {
    return (
      <div className="border border-slate-200 bg-white rounded-md p-8 text-center">
        <p className="text-sm text-slate-600">
          No AI systems registered. Create an intake record first to run an AI governance assessment.
        </p>
        <button
          type="button"
          onClick={() => onNavigate('intake')}
          className="mt-4 px-4 py-2 text-xs font-medium text-white bg-blue-700 rounded-md hover:bg-blue-800 cursor-pointer"
        >
          Create AI System Intake
        </button>
      </div>
    );
  }

  const assessment = activeSystem.assessment;

  const handleExportReport = () => {
    const md = generateSystemReportMarkdown(
      activeSystem,
      remediations,
      history,
      organisationName
    );
    downloadTextFile(`${activeSystem.intake.systemCode.toLowerCase()}-governance-report.md`, md);
  };

  const handleAddAction = (suggestion: RecommendedActionSuggestion) => {
    onAddRemediationFromSuggestion(activeSystem.intake.id, suggestion);
    setAddedTitles((prev) => ({
      ...prev,
      [`${activeSystem.intake.id}:${suggestion.title}`]: true,
    }));
  };

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-slate-500">
            Server-Side Gemini Triage · Non-Binding Decision Support
          </p>
          <h2 className="mt-1 text-2xl font-semibold tracking-tight text-slate-900">
            AI Governance Assessment
          </h2>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <select
            aria-label="Select AI system for assessment"
            value={activeSystem.intake.id}
            onChange={(e) => onSelectSystem(e.target.value)}
            className="px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
          >
            {systems.map((s) => (
              <option key={s.intake.id} value={s.intake.id}>
                {s.intake.systemCode} — {s.intake.name}
              </option>
            ))}
          </select>

          <button
            type="button"
            disabled={isAssessing}
            onClick={() => onRunAssessment(activeSystem.intake.id)}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-blue-700 rounded-md hover:bg-blue-800 disabled:opacity-60 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Play className="w-3.5 h-3.5" />
            <span>
              {isAssessing
                ? 'Running Gemini Triage...'
                : assessment
                ? 'Re-run AI Assessment'
                : 'Run AI Assessment'}
            </span>
          </button>

          <button
            type="button"
            onClick={handleExportReport}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-md hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Report</span>
          </button>
        </div>
      </div>

      {/* System Summary Context Bar */}
      <div className="border border-slate-200 bg-white rounded-md px-6 py-4 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
              <span className="font-mono font-semibold text-slate-800">
                {activeSystem.intake.systemCode}
              </span>
              <span aria-hidden="true">·</span>
              <span>{activeSystem.intake.department || 'Not provided'}</span>
              <span aria-hidden="true">·</span>
              <span>{activeSystem.intake.role}</span>
              <span aria-hidden="true">·</span>
              <span>Owner: {activeSystem.intake.businessOwner || 'Not provided'}</span>
            </div>
            <p className="text-sm font-semibold text-slate-900">{activeSystem.intake.name}</p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <ReviewStatusLabel status={activeSystem.review.overallStatus} />
            <button
              type="button"
              onClick={() => onNavigate('detail', activeSystem.intake.id)}
              className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-md hover:bg-slate-50 whitespace-nowrap cursor-pointer"
            >
              System Detail
            </button>
            <button
              type="button"
              onClick={() => onNavigate('review', activeSystem.intake.id)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-50 border border-slate-200 rounded-md hover:bg-slate-100 whitespace-nowrap cursor-pointer"
            >
              <UserCheck className="w-3.5 h-3.5" />
              <span>Human Review</span>
            </button>
          </div>
        </div>

        <div className="pt-3 border-t border-slate-100 grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-slate-600">
          <p>
            <strong className="text-slate-800">Purpose:</strong>{' '}
            {activeSystem.intake.businessPurpose || 'Not provided'}
          </p>
          <p>
            <strong className="text-slate-800">Business Process:</strong>{' '}
            {activeSystem.intake.businessProcess || 'Not provided'}
          </p>
          <p>
            <strong className="text-slate-800">Potential Data Categories:</strong>{' '}
            {activeSystem.intake.dataTypesProcessed || 'Not provided'}
          </p>
          <p>
            <strong className="text-slate-800">Evidence Required:</strong>{' '}
            {activeSystem.intake.evidenceRequired || 'Not provided'}
          </p>
        </div>
      </div>

      {/* Error State */}
      {assessmentError && (
        <div className="border border-red-200 bg-red-50 rounded-md p-4 text-xs text-red-800 space-y-1">
          <p className="font-semibold">AI Governance Assessment Error</p>
          <p>{assessmentError}</p>
        </div>
      )}

      {/* Loading Skeleton */}
      {isAssessing && (
        <div className="border border-slate-200 bg-white rounded-md p-6 space-y-4">
          <p className="text-xs font-medium text-blue-700">
            Analysing intake payload via server-side Gemini model ({activeSystem.intake.systemCode})...
          </p>
          <div className="space-y-3 animate-pulse">
            <div className="h-4 bg-slate-200 rounded w-3/4" />
            <div className="h-4 bg-slate-200 rounded w-full" />
            <div className="h-4 bg-slate-200 rounded w-5/6" />
          </div>
        </div>
      )}

      {/* Empty State */}
      {!assessment && !isAssessing && (
        <div className="border border-slate-200 bg-white rounded-md p-10 text-center space-y-3">
          <FileText className="w-8 h-8 text-slate-400 mx-auto" />
          <h3 className="text-sm font-semibold text-slate-900">
            Assessment Not Started
          </h3>
          <p className="text-xs text-slate-500 max-w-lg mx-auto leading-relaxed">
            No preliminary AI governance assessment has been generated for {activeSystem.intake.systemCode} yet. Run Gemini triage to separate confirmed intake facts from illustrative assumptions and missing evidence, surface potential EU AI Act and GDPR indicators, and prepare specialist review questions.
          </p>
          <button
            type="button"
            onClick={() => onRunAssessment(activeSystem.intake.id)}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-blue-700 rounded-md hover:bg-blue-800 cursor-pointer"
          >
            <Play className="w-3.5 h-3.5" />
            <span>Run AI Governance Assessment</span>
          </button>
        </div>
      )}

      {/* Populated Structured Assessment Output */}
      {assessment && !isAssessing && (
        <div className="space-y-6">
          {/* Safeguard & Executive Summary */}
          <div className="border border-slate-200 bg-white rounded-md divide-y divide-slate-200">
            <div className="px-6 py-3.5 bg-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-2 text-slate-700 font-medium">
                <ShieldCheck className="w-4 h-4 text-blue-700 shrink-0" />
                <span>{assessment.safeguardNotice}</span>
              </div>
              <span className="font-mono text-slate-500 whitespace-nowrap shrink-0">
                v{assessment.version} · {assessment.modelUsed} ·{' '}
                {formatIsoDateTime(assessment.generatedAt)}
              </span>
            </div>

            <div className="p-6 space-y-3">
              <h3 className="text-sm font-semibold text-slate-900">Executive Summary</h3>
              <p className="text-sm text-slate-700 leading-relaxed">
                {assessment.executiveSummary}
              </p>
              <div className="pt-3 border-t border-slate-100">
                <p className="text-xs font-semibold text-slate-700">
                  Confidence & Uncertainty Explanation
                </p>
                <p className="mt-1 text-xs text-slate-600 leading-relaxed">
                  {assessment.confidenceExplanation}
                </p>
              </div>
            </div>
          </div>

          {/* Epistemic Separation: Known Facts vs Assumptions vs Missing Info */}
          <div className="border border-slate-200 bg-white rounded-md grid grid-cols-1 lg:grid-cols-3 divide-y lg:divide-y-0 lg:divide-x divide-slate-200">
            <div className="p-6 space-y-3">
              <h3 className="text-sm font-semibold text-slate-900">
                Known Facts (Stated in Intake)
              </h3>
              <ul className="space-y-2 text-xs text-slate-700 list-disc pl-4">
                {assessment.knownFacts.length === 0 ? (
                  <li className="text-slate-400">No concrete facts verified.</li>
                ) : (
                  assessment.knownFacts.map((item, i) => <li key={i}>{item}</li>)
                )}
              </ul>
            </div>

            <div className="p-6 space-y-3">
              <h3 className="text-sm font-semibold text-slate-900">Working Assumptions</h3>
              <ul className="space-y-2 text-xs text-slate-700 list-disc pl-4">
                {assessment.assumptions.length === 0 ? (
                  <li className="text-slate-400">None recorded.</li>
                ) : (
                  assessment.assumptions.map((item, i) => <li key={i}>{item}</li>)
                )}
              </ul>
            </div>

            <div className="p-6 space-y-3 bg-amber-50/30">
              <h3 className="text-sm font-semibold text-amber-900">
                Missing Information & Evidence Gaps
              </h3>
              <ul className="space-y-2 text-xs text-amber-950 list-disc pl-4">
                {assessment.missingInformation.length === 0 ? (
                  <li className="text-slate-500">No critical gaps detected.</li>
                ) : (
                  assessment.missingInformation.map((item, i) => <li key={i}>{item}</li>)
                )}
              </ul>
            </div>
          </div>

          {/* Prohibited & High-Risk Specialist Indicators */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <section className="border border-slate-200 bg-white rounded-md p-6 space-y-4">
              <div className="flex items-center justify-between gap-2">
                <h3 className="text-sm font-semibold text-slate-900">
                  Potential Prohibited-Practice Indicators
                </h3>
                <span className="text-xs font-mono text-slate-500 tabular-nums">
                  {assessment.prohibitedPracticeIndicators.length} flagged
                </span>
              </div>
              {assessment.prohibitedPracticeIndicators.length === 0 ? (
                <p className="text-xs text-slate-500">
                  No prohibited-practice indicators detected from the submitted intake facts.
                </p>
              ) : (
                <div className="divide-y divide-slate-200">
                  {assessment.prohibitedPracticeIndicators.map((item, idx) => (
                    <div key={idx} className="py-3 first:pt-0 last:pb-0 space-y-1">
                      <p className="text-xs font-semibold text-red-700 flex items-center gap-1.5">
                        <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                        <span>{item.indicator}</span>
                      </p>
                      <p className="text-xs text-slate-700">{item.rationale}</p>
                      <p className="text-[11px] text-slate-500 font-medium">
                        Specialist Legal Review Required
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </section>

            <section className="border border-slate-200 bg-white rounded-md p-6 space-y-4">
              <div className="flex items-center justify-between gap-2">
                <h3 className="text-sm font-semibold text-slate-900">
                  Potential High-Risk Indicators
                </h3>
                <span className="text-xs font-mono text-slate-500 tabular-nums">
                  {assessment.highRiskIndicators.length} flagged
                </span>
              </div>
              {assessment.highRiskIndicators.length === 0 ? (
                <p className="text-xs text-slate-500">
                  No Annex III high-risk indicators triggered based on the submitted purpose and context.
                </p>
              ) : (
                <div className="divide-y divide-slate-200">
                  {assessment.highRiskIndicators.map((item, idx) => (
                    <div key={idx} className="py-3 first:pt-0 last:pb-0 space-y-1">
                      <p className="text-xs font-semibold text-amber-800 flex items-center gap-1.5">
                        <ShieldAlert className="w-3.5 h-3.5 shrink-0" />
                        <span>{item.indicator}</span>
                      </p>
                      <p className="text-xs text-slate-700">{item.rationale}</p>
                      <p className="text-[11px] text-slate-500 font-medium">
                        Specialist Legal / Compliance Review Required
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </section>
          </div>

          {/* Domain Triage Grid */}
          <div className="border border-slate-200 bg-white rounded-md grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-slate-200">
            <div className="p-6 space-y-6">
              <div>
                <h3 className="text-sm font-semibold text-slate-900">
                  Potential AI Act Applicability Questions
                </h3>
                <ul className="mt-2.5 space-y-2 text-xs text-slate-700 list-disc pl-4">
                  {assessment.potentialAiActQuestions.map((q, i) => (
                    <li key={i}>{q}</li>
                  ))}
                </ul>
              </div>

              <div className="pt-5 border-t border-slate-200">
                <h3 className="text-sm font-semibold text-slate-900">
                  GDPR & DPIA Triage Recommendations
                </h3>
                <ul className="mt-2.5 space-y-2 text-xs text-slate-700 list-disc pl-4">
                  {assessment.gdprAndDpiaTriage.map((item, i) => (
                    <li key={i}>{item}</li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="p-6 space-y-6">
              <div>
                <h3 className="text-sm font-semibold text-slate-900">
                  Security & Supplier Review Recommendations
                </h3>
                <ul className="mt-2.5 space-y-2 text-xs text-slate-700 list-disc pl-4">
                  {assessment.securityAndSupplierRecommendations.map((item, i) => (
                    <li key={i}>{item}</li>
                  ))}
                </ul>
              </div>

              <div className="pt-5 border-t border-slate-200">
                <h3 className="text-sm font-semibold text-slate-900">Human Oversight Gaps</h3>
                <ul className="mt-2.5 space-y-2 text-xs text-slate-700 list-disc pl-4">
                  {assessment.humanOversightGaps.length === 0 ? (
                    <li className="text-slate-500">No major oversight gaps flagged.</li>
                  ) : (
                    assessment.humanOversightGaps.map((item, i) => <li key={i}>{item}</li>)
                  )}
                </ul>
              </div>
            </div>
          </div>

          {/* Recommended Actions & Evidence Required */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <section className="lg:col-span-7 border border-slate-200 bg-white rounded-md">
              <div className="px-6 py-4 border-b border-slate-200">
                <h3 className="text-sm font-semibold text-slate-900">
                  Recommended Remediation Actions
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Send actions directly to the Remediation Tracker for owner assignment and due-date tracking
                </p>
              </div>
              <div className="divide-y divide-slate-200">
                {assessment.recommendedActions.map((act, i) => {
                  const key = `${activeSystem.intake.id}:${act.title}`;
                  const alreadyInTracker =
                    addedTitles[key] ||
                    remediations.some(
                      (r) => r.systemId === activeSystem.intake.id && r.title === act.title
                    );
                  return (
                    <div
                      key={i}
                      className="px-6 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 text-xs text-slate-500">
                          <span className="font-semibold text-slate-700">{act.priority} Priority</span>
                          <span aria-hidden="true">·</span>
                          <span>Suggested Role: {act.ownerRole}</span>
                        </div>
                        <p className="text-xs font-semibold text-slate-900">{act.title}</p>
                        <p className="text-xs text-slate-600">{act.rationale}</p>
                      </div>
                      <button
                        type="button"
                        disabled={alreadyInTracker}
                        onClick={() => handleAddAction(act)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 disabled:text-emerald-700 disabled:bg-emerald-50 disabled:border-emerald-200 whitespace-nowrap shrink-0 cursor-pointer"
                      >
                        {alreadyInTracker ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>In Tracker</span>
                          </>
                        ) : (
                          <>
                            <Plus className="w-3.5 h-3.5" />
                            <span>Add Action</span>
                          </>
                        )}
                      </button>
                    </div>
                  );
                })}
              </div>
            </section>

            <section className="lg:col-span-5 border border-slate-200 bg-white rounded-md p-6 space-y-6">
              <div>
                <h3 className="text-sm font-semibold text-slate-900">
                  Evidence Required Before Approval
                </h3>
                <ul className="mt-2.5 space-y-2 text-xs text-slate-700 list-disc pl-4">
                  {assessment.evidenceRequired.map((ev, i) => (
                    <li key={i}>{ev}</li>
                  ))}
                </ul>
              </div>

              <div className="pt-5 border-t border-slate-200">
                <h3 className="text-sm font-semibold text-slate-900">Source References</h3>
                <div className="mt-3 space-y-3">
                  {assessment.sourceReferences.map((ref, i) => (
                    <div key={i} className="text-xs space-y-0.5">
                      <p className="font-semibold text-slate-800">{ref.reference}</p>
                      <p className="text-slate-600">{ref.relevance}</p>
                      <p className="text-[11px] text-slate-500">{ref.verificationNote}</p>
                    </div>
                  ))}
                </div>
              </div>
            </section>
          </div>
        </div>
      )}
    </div>
  );
}
