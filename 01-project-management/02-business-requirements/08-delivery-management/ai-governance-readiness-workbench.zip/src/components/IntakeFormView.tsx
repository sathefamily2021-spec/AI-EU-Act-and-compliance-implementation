import { useEffect, useState } from 'react';
import { Play, Save } from 'lucide-react';
import type {
  AISystemIntake,
  AISystemRecord,
  EvidenceStatus,
  ProviderDeployerRole,
  TriState,
} from '../types/governance';

interface IntakeFormViewProps {
  systems: AISystemRecord[];
  selectedSystemId: string | null;
  onSelectSystem: (id: string | null) => void;
  onSaveIntake: (
    draft: Omit<AISystemIntake, 'id' | 'systemCode' | 'createdAt' | 'updatedAt'>,
    existingId: string | null,
    runAssessmentAfterSave: boolean
  ) => void;
}

const EMPTY_DRAFT: Omit<AISystemIntake, 'id' | 'systemCode' | 'createdAt' | 'updatedAt'> = {
  name: '',
  department: '',
  businessPurpose: '',
  businessProcess: '',
  businessOwner: '',
  role: 'Deployer — provisional assumption, subject to confirmation',
  intendedUsers: '',
  countryOfDeployment: '',
  aiFunctionality: '',
  dataTypesProcessed: '',
  personalDataInvolved: 'Unclear',
  specialCategoryDataInvolved: 'Unclear',
  affectsSensitiveDecisions: 'Unclear',
  sensitiveDecisionDetails: '',
  supplierInformation: '',
  humanOversightArrangements: '',
  supportingEvidence: '',
  evidenceRequired: '',
  illustrativeAssumptionsNote: '',
  evidenceStatus: 'Not Provided',
};

const ROLE_OPTIONS: ProviderDeployerRole[] = [
  'Deployer — provisional assumption, subject to confirmation',
  'Provider — provisional assumption, subject to confirmation',
  'Both (Provider & Deployer) — provisional assumption, subject to confirmation',
  'Deployer',
  'Provider',
  'Both (Provider & Deployer)',
  'To Be Confirmed',
  'Unclear — Needs Determination',
];

const EVIDENCE_STATUS_OPTIONS: EvidenceStatus[] = [
  'Not Provided',
  'Partial',
  'Complete',
  'To Be Confirmed',
];

const TRI_STATE_OPTIONS: TriState[] = ['Yes', 'No', 'Unclear'];

export function IntakeFormView({
  systems,
  selectedSystemId,
  onSelectSystem,
  onSaveIntake,
}: IntakeFormViewProps) {
  const editingRecord = systems.find((s) => s.intake.id === selectedSystemId) ?? null;
  const [draft, setDraft] = useState<
    Omit<AISystemIntake, 'id' | 'systemCode' | 'createdAt' | 'updatedAt'>
  >(EMPTY_DRAFT);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [savedNotice, setSavedNotice] = useState<string | null>(null);

  useEffect(() => {
    if (editingRecord) {
      const {
        id: _id,
        systemCode: _code,
        createdAt: _c,
        updatedAt: _u,
        ...rest
      } = editingRecord.intake;
      setDraft(rest);
    } else {
      setDraft(EMPTY_DRAFT);
    }
    setValidationError(null);
    setSavedNotice(null);
  }, [selectedSystemId, editingRecord]);

  const updateField = <K extends keyof typeof draft>(key: K, value: (typeof draft)[K]) => {
    setDraft((prev) => ({ ...prev, [key]: value }));
    setSavedNotice(null);
  };

  const handleSubmit = (runAfter: boolean) => {
    if (!draft.name.trim()) {
      setValidationError('AI system name is required before saving an intake record.');
      return;
    }
    setValidationError(null);
    onSaveIntake(draft, editingRecord?.intake.id ?? null, runAfter);
    if (!runAfter) {
      setSavedNotice(
        editingRecord
          ? `Updated intake record for ${draft.name}.`
          : `Created new AI system intake record for ${draft.name}.`
      );
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-slate-500">
            Structured Governance Intake · Untrusted Data Boundary
          </p>
          <h2 className="mt-1 text-2xl font-semibold tracking-tight text-slate-900">
            {editingRecord
              ? `Edit Intake · ${editingRecord.intake.systemCode}`
              : 'New AI System Intake'}
          </h2>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <select
            aria-label="Select existing system to edit or create new"
            value={selectedSystemId ?? 'new'}
            onChange={(e) => onSelectSystem(e.target.value === 'new' ? null : e.target.value)}
            className="px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-600"
          >
            <option value="new">+ Create New AI System Intake</option>
            {systems.map((s) => (
              <option key={s.intake.id} value={s.intake.id}>
                {s.intake.systemCode} — {s.intake.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {validationError && (
        <div className="p-4 border border-red-200 bg-red-50 rounded-md text-xs text-red-800 font-medium">
          {validationError}
        </div>
      )}

      {savedNotice && (
        <div className="p-4 border border-emerald-200 bg-emerald-50 rounded-md text-xs text-emerald-800 font-medium">
          {savedNotice}
        </div>
      )}

      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSubmit(false);
        }}
        className="border border-slate-200 bg-white rounded-md divide-y divide-slate-200"
      >
        {/* Section 1: Identity & Context */}
        <div className="p-6 space-y-5">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">
              1. System Identity, Ownership & Deployment Context
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Fields marked &quot;To Be Confirmed&quot; should be updated during discovery (WBS T02). Unknown details are flagged as missing information during AI triage.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                AI System Name <span className="text-red-600">*</span>
              </label>
              <input
                type="text"
                required
                value={draft.name}
                onChange={(e) => updateField('name', e.target.value)}
                placeholder="e.g., Customer Service Chatbot"
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Department
              </label>
              <input
                type="text"
                value={draft.department}
                onChange={(e) => updateField('department', e.target.value)}
                placeholder="e.g., Customer Operations"
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Business Owner (Role)
              </label>
              <input
                type="text"
                value={draft.businessOwner}
                onChange={(e) => updateField('businessOwner', e.target.value)}
                placeholder="e.g., Customer Operations Head"
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Provider or Deployer Role
              </label>
              <select
                value={draft.role}
                onChange={(e) => updateField('role', e.target.value as ProviderDeployerRole)}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              >
                {ROLE_OPTIONS.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Country of Deployment
              </label>
              <input
                type="text"
                value={draft.countryOfDeployment}
                onChange={(e) => updateField('countryOfDeployment', e.target.value)}
                placeholder="e.g., Germany, France, Luxembourg or To Be Confirmed"
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Intended Users
              </label>
              <input
                type="text"
                value={draft.intendedUsers}
                onChange={(e) => updateField('intendedUsers', e.target.value)}
                placeholder="e.g., Retail customers, Internal analysts, or To Be Confirmed"
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Business Purpose
              </label>
              <textarea
                rows={3}
                value={draft.businessPurpose}
                onChange={(e) => updateField('businessPurpose', e.target.value)}
                placeholder="Describe the intended business objective, operational workflow, and decisions informed by this system..."
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                AI Functionality & Technical Approach
              </label>
              <textarea
                rows={3}
                value={draft.aiFunctionality}
                onChange={(e) => updateField('aiFunctionality', e.target.value)}
                placeholder="e.g., Tabular risk scoring, LLM summarisation, or provisional assumption"
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Business Process
              </label>
              <input
                type="text"
                value={draft.businessProcess}
                onChange={(e) => updateField('businessProcess', e.target.value)}
                placeholder="e.g., Frontline customer support triage, complaint escalation, and agent assist"
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Illustrative Assumptions vs. Verification Note
              </label>
              <input
                type="text"
                value={draft.illustrativeAssumptionsNote}
                onChange={(e) => updateField('illustrativeAssumptionsNote', e.target.value)}
                placeholder="Distinguish illustrative assumptions from verified facts..."
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>
          </div>
        </div>

        {/* Section 2: Data & Sensitive Impact */}
        <div className="p-6 space-y-5">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">
              2. Data Processing & Impact Classification Inputs
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Used for GDPR/DPIA triage and Annex III impact scoping.
            </p>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1.5">
              Data Categories Processed
            </label>
            <textarea
              rows={2}
              value={draft.dataTypesProcessed}
              onChange={(e) => updateField('dataTypesProcessed', e.target.value)}
              placeholder="e.g., Customer KYC records, credit bureau scores, or To Be Confirmed"
              className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Personal Data Involved?
              </label>
              <select
                value={draft.personalDataInvolved}
                onChange={(e) => updateField('personalDataInvolved', e.target.value as TriState)}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              >
                {TRI_STATE_OPTIONS.map((opt) => (
                  <option key={opt} value={opt}>
                    {opt}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Special-Category Personal Data Involved?
              </label>
              <select
                value={draft.specialCategoryDataInvolved}
                onChange={(e) =>
                  updateField('specialCategoryDataInvolved', e.target.value as TriState)
                }
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              >
                {TRI_STATE_OPTIONS.map((opt) => (
                  <option key={opt} value={opt}>
                    {opt}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Affects Employment, Essential Services, or Credit?
              </label>
              <select
                value={draft.affectsSensitiveDecisions}
                onChange={(e) =>
                  updateField('affectsSensitiveDecisions', e.target.value as TriState)
                }
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              >
                {TRI_STATE_OPTIONS.map((opt) => (
                  <option key={opt} value={opt}>
                    {opt}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1.5">
              Sensitive Decision Context Details
            </label>
            <input
              type="text"
              value={draft.sensitiveDecisionDetails}
              onChange={(e) => updateField('sensitiveDecisionDetails', e.target.value)}
              placeholder="Explain how outputs affect natural persons' credit, employment, or essential banking access..."
              className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
          </div>
        </div>

        {/* Section 3: Supplier, Oversight & Supporting Evidence */}
        <div className="p-6 space-y-5">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">
              3. Supplier Assurance, Human Oversight & Supporting Evidence
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Submitted text is treated as untrusted input during AI triage.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Supplier Information
              </label>
              <textarea
                rows={3}
                value={draft.supplierInformation}
                onChange={(e) => updateField('supplierInformation', e.target.value)}
                placeholder="Vendor name, hosting region, DORA ICT status, certifications, or To Be Confirmed..."
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Human Oversight Arrangements
              </label>
              <textarea
                rows={3}
                value={draft.humanOversightArrangements}
                onChange={(e) => updateField('humanOversightArrangements', e.target.value)}
                placeholder="Describe human-in-the-loop checkpoints, override authority, or To Be Confirmed..."
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Evidence Status
              </label>
              <select
                value={draft.evidenceStatus}
                onChange={(e) => updateField('evidenceStatus', e.target.value as EvidenceStatus)}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              >
                {EVIDENCE_STATUS_OPTIONS.map((opt) => (
                  <option key={opt} value={opt}>
                    {opt}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Confirmed Supporting Evidence Available
              </label>
              <textarea
                rows={2}
                value={draft.supportingEvidence}
                onChange={(e) => updateField('supportingEvidence', e.target.value)}
                placeholder="List verified model cards, DPIA references, architecture docs, or leave blank if not yet provided..."
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Evidence Required for Verification
              </label>
              <textarea
                rows={2}
                value={draft.evidenceRequired}
                onChange={(e) => updateField('evidenceRequired', e.target.value)}
                placeholder="List required documents (e.g., Business use-case description, supplier documentation, technical architecture, data-flow diagram, privacy notice, human escalation procedure)..."
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>
          </div>
        </div>

        {/* Form Footer Actions */}
        <div className="px-6 py-4 bg-slate-50 flex flex-wrap items-center justify-between gap-3">
          <span className="text-xs text-slate-500">
            Changes are persisted locally and logged to Assessment History.
          </span>
          <div className="flex items-center gap-3">
            <button
              type="submit"
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-md hover:bg-slate-100 transition-colors whitespace-nowrap cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{editingRecord ? 'Save Changes' : 'Save Intake Record'}</span>
            </button>
            <button
              type="button"
              onClick={() => handleSubmit(true)}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-blue-700 rounded-md hover:bg-blue-800 transition-colors whitespace-nowrap cursor-pointer"
            >
              <Play className="w-3.5 h-3.5" />
              <span>Save & Run AI Assessment</span>
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}
