import {
  AlertTriangle,
  ArrowRight,
  CalendarClock,
  Download,
  FileCheck2,
  ShieldAlert,
} from 'lucide-react';
import type { ReviewStatus, WorkbenchState } from '../types/governance';
import {
  computeBusinessCaseMetrics,
  downloadTextFile,
  formatIsoDateTime,
  generateDashboardSummaryMarkdown,
} from '../utils/reporting';
import { isActionOverdue } from '../utils/storage';
import { computeWbsSchedule } from '../utils/wbs';
import { PriorityLabel, ReviewStatusLabel } from './StatusText';

interface DashboardViewProps {
  state: WorkbenchState;
  onNavigate: (tab: string, systemId?: string) => void;
}

const REVIEW_STATUS_ORDER: ReviewStatus[] = [
  'Not Started',
  'In Progress',
  'Pending Specialist Review',
  'Approved',
  'Rejected',
];

export function DashboardView({ state, onNavigate }: DashboardViewProps) {
  const totalSystems = state.systems.length;
  const completedAssessments = state.systems.filter((s) => s.assessment !== null).length;
  const awaitingHumanReview = state.systems.filter(
    (s) =>
      s.review.overallStatus === 'Pending Specialist Review' ||
      s.review.overallStatus === 'In Progress' ||
      s.review.overallStatus === 'Not Started'
  ).length;

  const openActions = state.remediations.filter((r) => r.status !== 'Completed');
  const overdueActions = openActions.filter((r) => isActionOverdue(r));

  const systemsWithHighPriorityIndicators = state.systems.filter(
    (s) =>
      (s.assessment?.prohibitedPracticeIndicators.length ?? 0) > 0 ||
      (s.assessment?.highRiskIndicators.length ?? 0) > 0
  );

  const prohibitedCount = state.systems.reduce(
    (acc, s) => acc + (s.assessment?.prohibitedPracticeIndicators.length ?? 0),
    0
  );
  const highRiskCount = state.systems.reduce(
    (acc, s) => acc + (s.assessment?.highRiskIndicators.length ?? 0),
    0
  );

  const statusCounts = REVIEW_STATUS_ORDER.map((status) => ({
    status,
    count: state.systems.filter((s) => s.review.overallStatus === status).length,
  }));

  const wbsSchedule = computeWbsSchedule(state.wbsTasks);
  const bcMetrics = computeBusinessCaseMetrics(state, 7);

  const handleDownloadSummary = () => {
    const md = generateDashboardSummaryMarkdown(state);
    downloadTextFile('eurofin-portfolio-governance-summary.md', md);
  };

  return (
    <div className="space-y-8">
      {/* Portfolio Header & Export Action */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-slate-500">
            {state.businessCase.organisation} · {state.businessCase.industry} ·{' '}
            {state.businessCase.employees.toLocaleString()} Employees ·{' '}
            {state.businessCase.projectDurationWeeks}-Week Delivery
          </p>
          <h2 className="mt-1 text-2xl font-semibold tracking-tight text-slate-900">
            AI Governance & Project Readiness Dashboard
          </h2>
        </div>
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={handleDownloadSummary}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-md hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Dashboard Summary</span>
          </button>
          <button
            type="button"
            onClick={() => onNavigate('intake')}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-blue-700 rounded-md hover:bg-blue-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <span>New AI System Intake</span>
          </button>
        </div>
      </div>

      {/* Primary KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 border border-slate-200 bg-white rounded-md divide-y sm:divide-y-0 sm:divide-x divide-slate-200">
        <div className="p-5">
          <p className="text-xs font-medium text-slate-500">Total AI Systems</p>
          <p className="mt-2 text-2xl font-semibold text-slate-900 tabular-nums font-mono">
            {totalSystems}
            <span className="text-sm font-normal text-slate-400">
              {' '}
              / {state.businessCase.aiSystemsInScope}
            </span>
          </p>
          <p className="mt-1 text-xs text-slate-500 tabular-nums">
            {bcMetrics.inventoryFieldCompletionPct}% fields confirmed
          </p>
        </div>

        <div className="p-5">
          <p className="text-xs font-medium text-slate-500">Assessments Completed</p>
          <p className="mt-2 text-2xl font-semibold text-slate-900 tabular-nums font-mono">
            {completedAssessments}
            <span className="text-sm font-normal text-slate-400"> / {totalSystems}</span>
          </p>
          <p className="mt-1 text-xs text-slate-500 tabular-nums">
            {totalSystems - completedAssessments} Not Started
          </p>
        </div>

        <div className="p-5">
          <p className="text-xs font-medium text-slate-500">Awaiting Human Review</p>
          <p className="mt-2 text-2xl font-semibold text-amber-700 tabular-nums font-mono">
            {awaitingHumanReview}
          </p>
          <p className="mt-1 text-xs text-slate-500">Specialist decision open</p>
        </div>

        <div className="p-5">
          <p className="text-xs font-medium text-slate-500">Open Actions</p>
          <p className="mt-2 text-2xl font-semibold text-slate-900 tabular-nums font-mono">
            {openActions.length}
          </p>
          <p className="mt-1 text-xs text-red-700 font-medium tabular-nums">
            {overdueActions.length} overdue
          </p>
        </div>

        <div className="p-5">
          <p className="text-xs font-medium text-slate-500">High-Priority Indicators</p>
          <p className="mt-2 text-2xl font-semibold text-red-700 tabular-nums font-mono">
            {prohibitedCount + highRiskCount}
          </p>
          <p className="mt-1 text-xs text-slate-500 tabular-nums">
            {prohibitedCount} prohibited · {highRiskCount} high-risk
          </p>
        </div>
      </div>

      {/* Connected Project Delivery & WBS Progress Strip */}
      <section className="border border-slate-200 bg-white rounded-md">
        <div className="px-6 py-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <CalendarClock className="w-4 h-4 text-blue-700 shrink-0" />
            <div>
              <h3 className="text-sm font-semibold text-slate-900">
                Project Delivery & WBS Progress ({state.businessCase.deliveryMethod})
              </h3>
              <p className="text-xs text-slate-500">
                Sponsor: {state.businessCase.projectSponsor} · Lead: {state.businessCase.businessLead} · Illustrative Budget: EUR{' '}
                {state.businessCase.illustrativeBudgetEur.toLocaleString()}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => onNavigate('business-case')}
              className="text-xs font-medium text-slate-700 hover:text-slate-900 cursor-pointer"
            >
              Business Case
            </button>
            <button
              type="button"
              onClick={() => onNavigate('wbs')}
              className="text-xs font-medium text-blue-700 hover:text-blue-800 inline-flex items-center gap-1 cursor-pointer"
            >
              <span>Open WBS Schedule</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <div className="p-6 grid grid-cols-1 md:grid-cols-4 gap-6 text-xs">
          <div>
            <p className="text-slate-500">Planned Duration (Critical Path)</p>
            <p className="mt-1 text-lg font-semibold font-mono tabular-nums text-slate-900">
              {wbsSchedule.projectDurationDays} working days
            </p>
            <p className="mt-0.5 text-slate-500 font-mono truncate" title={wbsSchedule.criticalPathIds.join(' → ')}>
              {wbsSchedule.criticalPathIds.join(' → ')}
            </p>
          </div>

          <div>
            <p className="text-slate-500">Weighted WBS Progress</p>
            <p className="mt-1 text-lg font-semibold font-mono tabular-nums text-slate-900">
              {wbsSchedule.overallActualProgress}%
            </p>
            <div className="mt-1.5 w-full h-2 bg-slate-100 rounded-sm overflow-hidden border border-slate-200">
              <div
                style={{ width: `${wbsSchedule.overallActualProgress}%` }}
                className="h-full bg-blue-700"
              />
            </div>
          </div>

          <div>
            <p className="text-slate-500">Work Package Breakdown</p>
            <p className="mt-1 font-mono tabular-nums text-slate-900 font-medium">
              {wbsSchedule.completedCount} Completed · {wbsSchedule.inProgressCount} In Progress
            </p>
            <p className="mt-0.5 font-mono tabular-nums text-slate-500">
              {wbsSchedule.notStartedCount} Not Started · {wbsSchedule.blockedCount} Blocked
            </p>
          </div>

          <div>
            <p className="text-slate-500">Evaluation & UAT Gate</p>
            <p className="mt-1 font-mono tabular-nums text-slate-900 font-medium">
              {bcMetrics.evalPassRatePct === null
                ? `0 / ${bcMetrics.evalTotalCount} scenarios tested`
                : `${bcMetrics.evalPassRatePct}% pass (${bcMetrics.evalTestedCount}/${bcMetrics.evalTotalCount})`}
            </p>
            <p className="mt-0.5 text-slate-500">Target: ≥90% pass rate</p>
          </div>
        </div>
      </section>

      {/* Main Two-Column Operational Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left 7 Cols: Assessment Status & Specialist Review Queue */}
        <section className="lg:col-span-7 border border-slate-200 bg-white rounded-md">
          <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-semibold text-slate-900">
                15-System Inventory & Assessment Queue
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Current governance status across EuroFin Services S.A. systems
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('register')}
              className="text-xs font-medium text-blue-700 hover:text-blue-800 inline-flex items-center gap-1 whitespace-nowrap cursor-pointer"
            >
              <span>Full Register</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Status Distribution Bar */}
          <div className="px-6 py-4 bg-slate-50/70 border-b border-slate-200 grid grid-cols-2 sm:grid-cols-5 gap-4">
            {statusCounts.map((item) => (
              <div key={item.status}>
                <p className="text-xs text-slate-500 truncate" title={item.status}>
                  {item.status}
                </p>
                <p className="mt-1 text-lg font-semibold text-slate-900 tabular-nums font-mono">
                  {item.count}
                </p>
              </div>
            ))}
          </div>

          {/* Systems Queue Table */}
          <div className="divide-y divide-slate-200 max-h-[540px] overflow-y-auto">
            {state.systems.length === 0 ? (
              <div className="p-8 text-center">
                <p className="text-sm text-slate-600">No AI systems registered yet.</p>
                <button
                  type="button"
                  onClick={() => onNavigate('intake')}
                  className="mt-3 px-4 py-2 text-xs font-medium text-white bg-blue-700 rounded-md hover:bg-blue-800 cursor-pointer"
                >
                  Log First AI System
                </button>
              </div>
            ) : (
              state.systems.map((record) => {
                const pCount = record.assessment?.prohibitedPracticeIndicators.length ?? 0;
                const hCount = record.assessment?.highRiskIndicators.length ?? 0;
                return (
                  <div
                    key={record.intake.id}
                    className="px-6 py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/80 transition-colors"
                  >
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                        <span className="font-mono font-medium text-slate-700">
                          {record.intake.systemCode}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>{record.intake.department}</span>
                        <span aria-hidden="true">·</span>
                        <span>Role: {record.intake.role}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => onNavigate('detail', record.intake.id)}
                        className="mt-0.5 text-sm font-semibold text-slate-900 hover:text-blue-700 truncate text-left block cursor-pointer"
                      >
                        {record.intake.name}
                      </button>
                      <div className="mt-0.5 flex flex-wrap items-center gap-2 text-xs text-slate-500">
                        <span>Owner: {record.intake.businessOwner || 'Not provided'}</span>
                        <span aria-hidden="true">·</span>
                        <span>Evidence: {record.intake.evidenceStatus}</span>
                        <span aria-hidden="true">·</span>
                        <span>
                          {record.assessment
                            ? `Triage v${record.assessment.version} (${formatIsoDateTime(record.assessment.generatedAt).slice(0, 10)})`
                            : 'Assessment Not Started'}
                        </span>
                        {(pCount > 0 || hCount > 0) && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="text-red-700 font-medium inline-flex items-center gap-1">
                              <ShieldAlert className="w-3.5 h-3.5" />
                              {pCount > 0 ? `${pCount} prohibited, ` : ''}
                              {hCount} high-risk
                            </span>
                          </>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <ReviewStatusLabel status={record.review.overallStatus} />
                      <button
                        type="button"
                        onClick={() =>
                          onNavigate(record.assessment ? 'review' : 'assessment', record.intake.id)
                        }
                        className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-md hover:bg-slate-100 transition-colors whitespace-nowrap cursor-pointer"
                      >
                        {record.assessment ? 'Review' : 'Assess'}
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </section>

        {/* Right 5 Cols: High-Priority Indicators & Open Remediation */}
        <div className="lg:col-span-5 space-y-6">
          <section className="border border-slate-200 bg-white rounded-md">
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-semibold text-slate-900">
                  High-Priority Specialist Indicators
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Populated only from completed AI-assisted triage assessments
                </p>
              </div>
              <FileCheck2 className="w-4 h-4 text-slate-400" />
            </div>

            <div className="divide-y divide-slate-200">
              {systemsWithHighPriorityIndicators.length === 0 ? (
                <div className="px-6 py-6 text-xs text-slate-500 space-y-2">
                  <p>
                    No prohibited-practice or high-risk indicators flagged yet ({completedAssessments} of {totalSystems} systems assessed).
                  </p>
                  <button
                    type="button"
                    onClick={() => onNavigate('assessment')}
                    className="text-blue-700 hover:text-blue-800 font-medium cursor-pointer"
                  >
                    Run AI Governance Assessment →
                  </button>
                </div>
              ) : (
                systemsWithHighPriorityIndicators.map((sys) => {
                  const pItems = sys.assessment?.prohibitedPracticeIndicators ?? [];
                  const hItems = sys.assessment?.highRiskIndicators ?? [];
                  return (
                    <div key={sys.intake.id} className="px-6 py-4 space-y-2">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-mono text-slate-500">
                          {sys.intake.systemCode}
                        </span>
                        <ReviewStatusLabel status={sys.review.overallStatus} />
                      </div>
                      <button
                        type="button"
                        onClick={() => onNavigate('assessment', sys.intake.id)}
                        className="text-sm font-semibold text-slate-900 hover:text-blue-700 text-left cursor-pointer"
                      >
                        {sys.intake.name}
                      </button>
                      <ul className="space-y-1.5 text-xs">
                        {pItems.map((p, idx) => (
                          <li key={`p-${idx}`} className="text-red-700 flex items-start gap-1.5">
                            <AlertTriangle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
                            <span>
                              <strong>Prohibited-Practice Trigger:</strong> {p.indicator}
                            </span>
                          </li>
                        ))}
                        {hItems.map((h, idx) => (
                          <li key={`h-${idx}`} className="text-amber-800 flex items-start gap-1.5">
                            <ShieldAlert className="w-3.5 h-3.5 mt-0.5 shrink-0" />
                            <span>
                              <strong>High-Risk Trigger:</strong> {h.indicator}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  );
                })
              )}
            </div>
          </section>

          <section className="border border-slate-200 bg-white rounded-md">
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-semibold text-slate-900">
                  Open & Overdue Remediation
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Actions linked directly to in-scope AI systems
                </p>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('remediation')}
                className="text-xs font-medium text-blue-700 hover:text-blue-800 inline-flex items-center gap-1 whitespace-nowrap cursor-pointer"
              >
                <span>Tracker</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="divide-y divide-slate-200">
              {openActions.length === 0 ? (
                <div className="px-6 py-6 text-xs text-slate-500 space-y-2">
                  <p>
                    No remediation actions recorded yet. Actions created in the Remediation Tracker or from AI Assessment recommendations appear here.
                  </p>
                  <button
                    type="button"
                    onClick={() => onNavigate('remediation')}
                    className="text-blue-700 hover:text-blue-800 font-medium cursor-pointer"
                  >
                    Create Remediation Action →
                  </button>
                </div>
              ) : (
                openActions.slice(0, 5).map((action) => {
                  const overdue = isActionOverdue(action);
                  const sys = state.systems.find((s) => s.intake.id === action.systemId);
                  return (
                    <div key={action.id} className="px-6 py-3.5 space-y-1">
                      <div className="flex items-center justify-between gap-2 text-xs">
                        <span className="font-mono text-slate-500">
                          {sys?.intake.systemCode ?? '—'} · Due {action.dueDate}
                        </span>
                        <div className="flex items-center gap-2">
                          {overdue && (
                            <span className="text-xs font-semibold text-red-700">OVERDUE</span>
                          )}
                          <PriorityLabel priority={action.priority} />
                        </div>
                      </div>
                      <p className="text-xs font-medium text-slate-900">{action.title}</p>
                      <p className="text-xs text-slate-500">
                        Owner: {action.owner} · Status: {action.status}
                      </p>
                    </div>
                  );
                })
              )}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
