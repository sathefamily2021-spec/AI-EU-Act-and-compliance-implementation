import { useEffect, useState } from 'react';
import { Download, FileText, Printer } from 'lucide-react';
import type { WorkbenchState } from '../types/governance';
import {
  downloadTextFile,
  generateDashboardSummaryMarkdown,
  generateSystemReportMarkdown,
} from '../utils/reporting';

interface ReportingViewProps {
  state: WorkbenchState;
  selectedSystemId: string | null;
  onSelectSystem: (id: string) => void;
}

export function ReportingView({
  state,
  selectedSystemId,
  onSelectSystem,
}: ReportingViewProps) {
  const [reportType, setReportType] = useState<'system' | 'dashboard'>('system');
  const [chosenSystemId, setChosenSystemId] = useState<string>(
    selectedSystemId ?? state.systems[0]?.intake.id ?? ''
  );

  // Sync chosen system whenever selectedSystemId changes from Register / Detail / Assessment
  useEffect(() => {
    if (selectedSystemId && state.systems.some((s) => s.intake.id === selectedSystemId)) {
      setChosenSystemId(selectedSystemId);
    }
  }, [selectedSystemId, state.systems]);

  const selectedSystem =
    state.systems.find((s) => s.intake.id === chosenSystemId) ?? state.systems[0] ?? null;

  const previewContent =
    reportType === 'dashboard'
      ? generateDashboardSummaryMarkdown(state)
      : selectedSystem
      ? generateSystemReportMarkdown(
          selectedSystem,
          state.remediations,
          state.history,
          state.organisationName
        )
      : 'No AI system selected.';

  const handleDownloadMarkdown = () => {
    if (reportType === 'dashboard') {
      downloadTextFile('eurofin-portfolio-governance-summary.md', previewContent);
    } else if (selectedSystem) {
      downloadTextFile(
        `${selectedSystem.intake.systemCode.toLowerCase()}-governance-report.md`,
        previewContent
      );
    }
  };

  const handleDownloadHtml = () => {
    const escaped = previewContent
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
    const htmlDoc = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>AI Governance Report</title>
<style>
  body { font-family: system-ui, -apple-system, sans-serif; max-width: 900px; margin: 40px auto; padding: 0 24px; color: #0f172a; line-height: 1.6; }
  pre { white-space: pre-wrap; font-family: ui-monospace, monospace; font-size: 13px; background: #f8fafc; padding: 24px; border: 1px solid #e2e8f0; border-radius: 6px; }
</style>
</head>
<body>
<pre>${escaped}</pre>
</body>
</html>`;
    const filename =
      reportType === 'dashboard'
        ? 'eurofin-portfolio-governance-summary.html'
        : `${selectedSystem?.intake.systemCode.toLowerCase() ?? 'system'}-governance-report.html`;
    downloadTextFile(filename, htmlDoc, 'text/html;charset=utf-8');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 no-print">
        <div>
          <p className="text-xs font-medium text-slate-500">
            Generated Directly From Saved System Records & Live Assessment Outputs
          </p>
          <h2 className="mt-1 text-2xl font-semibold tracking-tight text-slate-900">
            Governance Reporting
          </h2>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={() => window.print()}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-md hover:bg-slate-50 whitespace-nowrap cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print / PDF</span>
          </button>
          <button
            type="button"
            onClick={handleDownloadHtml}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-md hover:bg-slate-50 whitespace-nowrap cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Download HTML</span>
          </button>
          <button
            type="button"
            onClick={handleDownloadMarkdown}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-blue-700 rounded-md hover:bg-blue-800 whitespace-nowrap cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Report (.md)</span>
          </button>
        </div>
      </div>

      {/* Report Configuration Bar */}
      <div className="border border-slate-200 bg-white rounded-md p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 no-print">
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-md w-fit">
          <button
            type="button"
            onClick={() => setReportType('system')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap cursor-pointer ${
              reportType === 'system'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Individual System Assessment Report
          </button>
          <button
            type="button"
            onClick={() => setReportType('dashboard')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap cursor-pointer ${
              reportType === 'dashboard'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Portfolio Dashboard Summary
          </button>
        </div>

        {reportType === 'system' && (
          <select
            aria-label="Select AI system for report"
            value={chosenSystemId}
            onChange={(e) => {
              setChosenSystemId(e.target.value);
              onSelectSystem(e.target.value);
            }}
            className="px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-md text-slate-900"
          >
            {state.systems.map((s) => (
              <option key={s.intake.id} value={s.intake.id}>
                {s.intake.systemCode} — {s.intake.name}
              </option>
            ))}
          </select>
        )}
      </div>

      {/* Readable Preview */}
      <div className="border border-slate-200 bg-white rounded-md p-6">
        <div className="pb-3 mb-4 border-b border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span>Live Report Preview (Derived from Saved Record)</span>
          <span className="font-mono">
            {reportType === 'dashboard'
              ? 'eurofin-portfolio-governance-summary.md'
              : `${selectedSystem?.intake.systemCode.toLowerCase() ?? 'system'}-governance-report.md`}
          </span>
        </div>
        <pre className="whitespace-pre-wrap font-mono text-xs text-slate-800 leading-relaxed overflow-x-auto">
          {previewContent}
        </pre>
      </div>
    </div>
  );
}
