import { useState } from 'react';
import { CheckCircle2, CircleDashed, Clock, Edit3, Flag, Save, XCircle } from 'lucide-react';
import type { ComputedWbsTask, WbsTaskInput, WbsTaskStatus } from '../types/governance';
import { computeWbsSchedule, formatWorkingDay } from '../utils/wbs';

interface WbsDeliveryViewProps {
  wbsTasks: WbsTaskInput[];
  onUpdateTask: (updatedTask: WbsTaskInput) => void;
}

const WBS_STATUSES: WbsTaskStatus[] = ['Not Started', 'In Progress', 'Blocked', 'Completed'];

export function WbsDeliveryView({ wbsTasks, onUpdateTask }: WbsDeliveryViewProps) {
  const schedule = computeWbsSchedule(wbsTasks);
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null);
  const [editDraft, setEditDraft] = useState<WbsTaskInput | null>(null);
  const [filterMode, setFilterMode] = useState<'all' | 'critical'>('all');

  const visibleTasks =
    filterMode === 'critical'
      ? schedule.tasks.filter((t) => t.isCriticalPath)
      : schedule.tasks;

  const startEditing = (task: ComputedWbsTask) => {
    setEditingTaskId(task.id);
    setEditDraft({
      id: task.id,
      name: task.name,
      durationDays: task.durationDays,
      accountableOwner: task.accountableOwner,
      supportingRoles: task.supportingRoles,
      predecessors: task.predecessors,
      plannedProgress: task.plannedProgress,
      actualProgress: task.actualProgress,
      actualStartDay: task.actualStartDay,
      actualFinishDay: task.actualFinishDay,
      status: task.status,
      milestone: task.milestone,
      deliverable: task.deliverable,
      notes: task.notes,
    });
  };

  const handleSaveEdit = () => {
    if (!editDraft) return;
    const clampedActual = Math.min(100, Math.max(0, Math.round(editDraft.actualProgress)));
    const clampedPlanned = Math.min(100, Math.max(0, Math.round(editDraft.plannedProgress)));
    onUpdateTask({
      ...editDraft,
      durationDays: Math.max(1, Math.round(editDraft.durationDays)),
      actualProgress: clampedActual,
      plannedProgress: clampedPlanned,
    });
    setEditingTaskId(null);
    setEditDraft(null);
  };

  const renderStatus = (status: WbsTaskStatus) => {
    switch (status) {
      case 'Completed':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700 whitespace-nowrap">
            <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
            <span>Completed</span>
          </span>
        );
      case 'In Progress':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-blue-700 whitespace-nowrap">
            <Clock className="w-3.5 h-3.5 shrink-0" />
            <span>In Progress</span>
          </span>
        );
      case 'Blocked':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-red-700 whitespace-nowrap">
            <XCircle className="w-3.5 h-3.5 shrink-0" />
            <span>Blocked</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-600 whitespace-nowrap">
            <CircleDashed className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span>Not Started</span>
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-slate-500">
            Finish-to-Start CPM · 5-Working-Day Calendar · No Resource Levelling
          </p>
          <h2 className="mt-1 text-2xl font-semibold tracking-tight text-slate-900">
            WBS & Project Delivery Schedule
          </h2>
        </div>

        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-md w-fit">
          <button
            type="button"
            onClick={() => setFilterMode('all')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors cursor-pointer ${
              filterMode === 'all'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All Work Packages ({schedule.tasks.length})
          </button>
          <button
            type="button"
            onClick={() => setFilterMode('critical')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors cursor-pointer ${
              filterMode === 'critical'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Critical Path Only ({schedule.criticalPathIds.length})
          </button>
        </div>
      </div>

      {/* CPM Summary KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 border border-slate-200 bg-white rounded-md divide-y sm:divide-y-0 sm:divide-x divide-slate-200">
        <div className="p-5">
          <p className="text-xs font-medium text-slate-500">Planned Project Duration</p>
          <p className="mt-2 text-2xl font-semibold text-slate-900 font-mono tabular-nums">
            {schedule.projectDurationDays} days
          </p>
          <p className="mt-1 text-xs text-slate-500">8-week delivery baseline</p>
        </div>

        <div className="p-5">
          <p className="text-xs font-medium text-slate-500">Critical Path Sequence</p>
          <p className="mt-2 text-xs font-mono font-semibold text-red-700 leading-relaxed">
            {schedule.criticalPathIds.join(' → ')}
          </p>
          <p className="mt-1 text-xs text-slate-500">Zero total float tasks</p>
        </div>

        <div className="p-5">
          <p className="text-xs font-medium text-slate-500">Weighted Actual Progress</p>
          <p className="mt-2 text-2xl font-semibold text-slate-900 font-mono tabular-nums">
            {schedule.overallActualProgress}%
          </p>
          <p className="mt-1 text-xs text-slate-500">Across 13 work packages</p>
        </div>

        <div className="p-5">
          <p className="text-xs font-medium text-slate-500">Work Package Status</p>
          <p className="mt-2 text-xs font-mono tabular-nums text-slate-900">
            {schedule.completedCount} Completed · {schedule.inProgressCount} In Progress
          </p>
          <p className="mt-1 text-xs font-mono tabular-nums text-slate-500">
            {schedule.notStartedCount} Not Started · {schedule.blockedCount} Blocked
          </p>
        </div>

        <div className="p-5">
          <p className="text-xs font-medium text-slate-500">Non-Critical Float</p>
          <p className="mt-2 text-xs font-mono text-slate-800">
            T10: 1d · T05/T06/T11: 6d
          </p>
          <p className="mt-1 text-xs text-slate-500">Recalculates on duration edit</p>
        </div>
      </div>

      {/* Interactive Edit Drawer/Panel when a task is selected */}
      {editDraft && (
        <section className="border border-blue-200 bg-white rounded-md p-6 space-y-4">
          <div className="flex items-center justify-between gap-4">
            <div>
              <p className="text-xs font-mono font-semibold text-blue-700">{editDraft.id}</p>
              <h3 className="text-sm font-semibold text-slate-900">
                Update Work Package: {editDraft.name}
              </h3>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  setEditingTaskId(null);
                  setEditDraft(null);
                }}
                className="px-3 py-1.5 text-xs font-medium text-slate-700 border border-slate-200 rounded-md hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveEdit}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white bg-blue-700 rounded-md hover:bg-blue-800 cursor-pointer"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Save Work Package</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Status</label>
              <select
                value={editDraft.status}
                onChange={(e) => {
                  const nextStatus = e.target.value as WbsTaskStatus;
                  setEditDraft((prev) =>
                    prev
                      ? {
                          ...prev,
                          status: nextStatus,
                          actualProgress:
                            nextStatus === 'Completed'
                              ? 100
                              : nextStatus === 'Not Started'
                              ? 0
                              : prev.actualProgress,
                        }
                      : null
                  );
                }}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md"
              >
                {WBS_STATUSES.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Duration (Working Days)
              </label>
              <input
                type="number"
                min={1}
                max={30}
                value={editDraft.durationDays}
                onChange={(e) =>
                  setEditDraft((prev) =>
                    prev ? { ...prev, durationDays: Number(e.target.value) || 1 } : null
                  )
                }
                className="w-full px-3 py-2 text-xs font-mono bg-white border border-slate-200 rounded-md"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Planned Progress (%)
              </label>
              <input
                type="number"
                min={0}
                max={100}
                value={editDraft.plannedProgress}
                onChange={(e) =>
                  setEditDraft((prev) =>
                    prev ? { ...prev, plannedProgress: Number(e.target.value) || 0 } : null
                  )
                }
                className="w-full px-3 py-2 text-xs font-mono bg-white border border-slate-200 rounded-md"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Actual Progress (%)
              </label>
              <input
                type="number"
                min={0}
                max={100}
                value={editDraft.actualProgress}
                onChange={(e) =>
                  setEditDraft((prev) =>
                    prev ? { ...prev, actualProgress: Number(e.target.value) || 0 } : null
                  )
                }
                className="w-full px-3 py-2 text-xs font-mono bg-white border border-slate-200 rounded-md"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Actual Start Day
              </label>
              <input
                type="number"
                min={1}
                placeholder="—"
                value={editDraft.actualStartDay ?? ''}
                onChange={(e) =>
                  setEditDraft((prev) =>
                    prev
                      ? {
                          ...prev,
                          actualStartDay: e.target.value ? Number(e.target.value) : null,
                        }
                      : null
                  )
                }
                className="w-full px-3 py-2 text-xs font-mono bg-white border border-slate-200 rounded-md"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Actual Finish Day
              </label>
              <input
                type="number"
                min={1}
                placeholder="—"
                value={editDraft.actualFinishDay ?? ''}
                onChange={(e) =>
                  setEditDraft((prev) =>
                    prev
                      ? {
                          ...prev,
                          actualFinishDay: e.target.value ? Number(e.target.value) : null,
                        }
                      : null
                  )
                }
                className="w-full px-3 py-2 text-xs font-mono bg-white border border-slate-200 rounded-md"
              />
            </div>

            <div className="sm:col-span-2 lg:col-span-6">
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Delivery Notes
              </label>
              <input
                type="text"
                value={editDraft.notes}
                onChange={(e) =>
                  setEditDraft((prev) => (prev ? { ...prev, notes: e.target.value } : null))
                }
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md"
              />
            </div>
          </div>
        </section>
      )}

      {/* High-Density WBS & CPM Schedule Table */}
      <div className="border border-slate-200 bg-white rounded-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                <th className="py-3 px-4 whitespace-nowrap">WBS</th>
                <th className="py-3 px-4 min-w-[200px]">Work Package & Deliverable</th>
                <th className="py-3 px-4 min-w-[150px]">Owner & Support</th>
                <th className="py-3 px-4 whitespace-nowrap">Pred.</th>
                <th className="py-3 px-4 text-right whitespace-nowrap">Dur.</th>
                <th className="py-3 px-4 whitespace-nowrap">Start → Finish</th>
                <th className="py-3 px-4 min-w-[140px]">Timeline (38d)</th>
                <th className="py-3 px-4 text-right whitespace-nowrap">Float</th>
                <th className="py-3 px-4 whitespace-nowrap">Critical</th>
                <th className="py-3 px-4 text-right whitespace-nowrap">Plan / Act</th>
                <th className="py-3 px-4 text-right whitespace-nowrap">Var.</th>
                <th className="py-3 px-4 whitespace-nowrap">Status</th>
                <th className="py-3 px-4 text-right whitespace-nowrap">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-xs">
              {visibleTasks.map((task) => {
                const leftPct =
                  schedule.projectDurationDays > 0
                    ? ((task.startDay - 1) / schedule.projectDurationDays) * 100
                    : 0;
                const widthPct =
                  schedule.projectDurationDays > 0
                    ? (task.durationDays / schedule.projectDurationDays) * 100
                    : 10;

                return (
                  <tr
                    key={task.id}
                    className={`hover:bg-slate-50/80 align-top ${
                      editingTaskId === task.id ? 'bg-blue-50/40' : ''
                    }`}
                  >
                    <td className="py-3.5 px-4 font-mono font-semibold text-slate-800 whitespace-nowrap">
                      {task.id}
                    </td>
                    <td className="py-3.5 px-4">
                      <p className="font-semibold text-slate-900">{task.name}</p>
                      <p className="text-[11px] text-slate-600 mt-0.5">
                        Deliverable: {task.deliverable}
                      </p>
                      {task.milestone !== '—' && (
                        <p className="text-[11px] text-blue-700 font-medium mt-0.5 inline-flex items-center gap-1">
                          <Flag className="w-3 h-3 shrink-0" />
                          <span>{task.milestone}</span>
                        </p>
                      )}
                    </td>
                    <td className="py-3.5 px-4">
                      <p className="font-medium text-slate-900">{task.accountableOwner}</p>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Support: {task.supportingRoles.join(', ')}
                      </p>
                    </td>
                    <td className="py-3.5 px-4 font-mono text-slate-600 whitespace-nowrap">
                      {task.predecessors.length ? task.predecessors.join(', ') : '—'}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono tabular-nums text-slate-900 whitespace-nowrap">
                      {task.durationDays}d
                    </td>
                    <td className="py-3.5 px-4 font-mono tabular-nums text-slate-700 whitespace-nowrap">
                      <span>{formatWorkingDay(task.startDay)}</span>
                      <span className="block text-[11px] text-slate-500">
                        → {formatWorkingDay(task.finishDay)}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 align-middle">
                      <div className="w-32 h-2.5 bg-slate-100 rounded-sm relative overflow-hidden border border-slate-200">
                        <div
                          style={{
                            left: `${leftPct}%`,
                            width: `${Math.max(widthPct, 4)}%`,
                          }}
                          className={`absolute top-0 bottom-0 ${
                            task.isCriticalPath ? 'bg-red-600' : 'bg-blue-600'
                          }`}
                        />
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono tabular-nums text-slate-700 whitespace-nowrap">
                      {task.totalFloat}d
                    </td>
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      {task.isCriticalPath ? (
                        <span className="text-red-700 font-semibold">Critical</span>
                      ) : (
                        <span className="text-slate-500">Non-critical</span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono tabular-nums text-slate-700 whitespace-nowrap">
                      {task.plannedProgress}% / {task.actualProgress}%
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono tabular-nums whitespace-nowrap">
                      {task.scheduleVarianceDays === 0 ? (
                        <span className="text-slate-500">0d</span>
                      ) : task.scheduleVarianceDays > 0 ? (
                        <span className="text-red-700 font-semibold">
                          +{task.scheduleVarianceDays}d
                        </span>
                      ) : (
                        <span className="text-emerald-700 font-semibold">
                          {task.scheduleVarianceDays}d
                        </span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 whitespace-nowrap">{renderStatus(task.status)}</td>
                    <td className="py-3.5 px-4 text-right whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => startEditing(task)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-700 border border-slate-200 rounded hover:bg-slate-100 cursor-pointer"
                      >
                        <Edit3 className="w-3 h-3" />
                        <span>Edit</span>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
