import { useMemo, useState } from 'react';
import { Download, Plus, Search } from 'lucide-react';
import type { ReviewStatus, WorkbenchState } from '../types/governance';
import { downloadTextFile, generateSystemReportMarkdown } from '../utils/reporting';
import { isActionOverdue } from '../utils/storage';
import { ReviewStatusLabel } from './StatusText';

interface RegisterViewProps {
  state: WorkbenchState;
  onNavigate: (tab: string, systemId?: string) => void;
}

const STATUS_FILTERS: Array<'All' | ReviewStatus> = [
  'All',
  'Not Started',
  'In Progress',
  'Pending Specialist Review',
  'Approved',
  'Rejected',
];

export function RegisterView({ state, onNavigate }: RegisterViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | ReviewStatus>('All');

  const filteredSystems = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return state.systems.filter((record) => {
      const matchesStatus =
        statusFilter === 'All' || record.review.overallStatus === statusFilter;
      if (!matchesStatus) return false;
      if (!q) return true;
      return (
        record.intake.systemCode.toLowerCase().includes(q) ||
        record.intake.name.toLowerCase().includes(q) ||
        record.intake.department.toLowerCase().includes(q) ||
        record.intake.businessOwner.toLowerCase().includes(q) ||
        record.intake.role.toLowerCase().includes(q) ||
        record.intake.dataTypesProcessed.toLowerCase().includes(q)
      );
    });
  }, [state.systems, searchQuery, statusFilter]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-slate-500">
            {state.organisationName} · {state.systems.length} Systems in Central Inventory
          </p>
          <h2 className="mt-1 text-2xl font-semibold tracking-tight text-slate-900">
            AI System Register
          </h2>
        </div>
        <button
          type="button"
          onClick={() => onNavigate('intake')}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-blue-700 rounded-md hover:bg-blue-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Register AI System</span>
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="border border-slate-200 bg-white rounded-md p-4 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by code, system name, department, owner, or data category..."
            className="w-full pl-9 pr-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-blue-600"
          />
        </div>

        <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-md">
          {STATUS_FILTERS.map((status) => (
            <button
              key={status}
              type="button"
              onClick={() => setStatusFilter(status)}
              className={`px-2.5 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                statusFilter === status
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {status}
            </button>
          ))}
        </div>
      </div>

      {/* Dense Register Table */}
      <div className="border border-slate-200 bg-white rounded-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                <th className="py-3 px-3 whitespace-nowrap">System ID</th>
                <th className="py-3 px-3 min-w-[210px]">System & Purpose</th>
                <th className="py-3 px-3 min-w-[140px]">Department & Owner</th>
                <th className="py-3 px-3 min-w-[180px]">Provisional Role & Data Categories</th>
                <th className="py-3 px-3 min-w-[150px]">Intended Users & Evidence</th>
                <th className="py-3 px-3 whitespace-nowrap">Assessment & Review</th>
                <th className="py-3 px-3 min-w-[175px]">Specialist Reviewers</th>
                <th className="py-3 px-3 text-right whitespace-nowrap">Actions</th>
                <th className="py-3 px-3 text-right whitespace-nowrap">Workspace</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-xs">
              {filteredSystems.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-10 px-4 text-center text-slate-500">
                    No AI systems match the current search or status filter.
                  </td>
                </tr>
              ) : (
                filteredSystems.map((record) => {
                  const sysActions = state.remediations.filter(
                    (r) => r.systemId === record.intake.id && r.status !== 'Completed'
                  );
                  const overdueCount = sysActions.filter((r) => isActionOverdue(r)).length;
                  const areas = record.review.areas;

                  return (
                    <tr
                      key={record.intake.id}
                      className="hover:bg-slate-50/80 transition-colors align-top"
                    >
                      <td className="py-3.5 px-3 font-mono font-semibold text-slate-800 whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => onNavigate('detail', record.intake.id)}
                          className="hover:text-blue-700 underline decoration-slate-300 underline-offset-2 cursor-pointer"
                        >
                          {record.intake.systemCode}
                        </button>
                      </td>
                      <td className="py-3.5 px-3">
                        <button
                          type="button"
                          onClick={() => onNavigate('detail', record.intake.id)}
                          className="font-semibold text-slate-900 hover:text-blue-700 text-left cursor-pointer"
                        >
                          {record.intake.name}
                        </button>
                        <p className="text-slate-500 mt-0.5 line-clamp-2">
                          {record.intake.businessPurpose || 'Not provided'}
                        </p>
                      </td>
                      <td className="py-3.5 px-3">
                        <p className="font-medium text-slate-800">
                          {record.intake.department || 'Not provided'}
                        </p>
                        <p className="text-slate-500 mt-0.5">
                          {record.intake.businessOwner || 'Not provided'}
                        </p>
                      </td>
                      <td className="py-3.5 px-3">
                        <p className="font-medium text-slate-800">{record.intake.role}</p>
                        <p className="text-slate-500 mt-0.5 line-clamp-2">
                          {record.intake.dataTypesProcessed || 'Not provided'}
                        </p>
                      </td>
                      <td className="py-3.5 px-3">
                        <p className="text-slate-700 line-clamp-2">
                          {record.intake.intendedUsers || 'Not provided'}
                        </p>
                        <p className="text-slate-500 mt-0.5">
                          Evidence: {record.intake.evidenceStatus}
                        </p>
                      </td>
                      <td className="py-3.5 px-3">
                        <ReviewStatusLabel status={record.review.overallStatus} />
                        <p className="text-[11px] text-slate-500 mt-1 font-mono">
                          {record.assessment
                            ? `AI Triage v${record.assessment.version}`
                            : 'Assessment Not Started'}
                        </p>
                      </td>
                      <td className="py-3.5 px-3 text-[11px] text-slate-600 space-y-0.5">
                        <p>
                          Legal: <span className="font-medium text-slate-800">{areas.legalCompliance.reviewerName}</span> ({areas.legalCompliance.status})
                        </p>
                        <p>
                          DPO: <span className="font-medium text-slate-800">{areas.dpo.reviewerName}</span> ({areas.dpo.status})
                        </p>
                        <p>
                          Security: <span className="font-medium text-slate-800">{areas.cisoSecurity.reviewerName}</span> ({areas.cisoSecurity.status})
                        </p>
                      </td>
                      <td className="py-3.5 px-3 text-right font-mono tabular-nums whitespace-nowrap">
                        <span className="text-slate-900 font-medium">{sysActions.length}</span>
                        {overdueCount > 0 && (
                          <span className="block text-[11px] text-red-700 font-sans font-medium">
                            {overdueCount} overdue
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-3 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => onNavigate('detail', record.intake.id)}
                            className="px-2 py-1 text-xs font-medium text-slate-700 border border-slate-200 rounded hover:bg-slate-100 cursor-pointer"
                          >
                            View
                          </button>
                          <button
                            type="button"
                            onClick={() => onNavigate('intake', record.intake.id)}
                            className="px-2 py-1 text-xs font-medium text-slate-700 border border-slate-200 rounded hover:bg-slate-100 cursor-pointer"
                          >
                            Edit
                          </button>
                          <button
                            type="button"
                            onClick={() => onNavigate('assessment', record.intake.id)}
                            className="px-2 py-1 text-xs font-medium text-blue-700 border border-blue-200 rounded hover:bg-blue-50 cursor-pointer"
                          >
                            Assess
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              const md = generateSystemReportMarkdown(
                                record,
                                state.remediations,
                                state.history,
                                state.organisationName
                              );
                              downloadTextFile(
                                `${record.intake.systemCode.toLowerCase()}-governance-report.md`,
                                md
                              );
                            }}
                            title="Export Report"
                            className="p-1.5 text-slate-600 border border-slate-200 rounded hover:bg-slate-100 cursor-pointer"
                          >
                            <Download className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
