import {
  AlertOctagon,
  AlertTriangle,
  CheckCircle2,
  CircleDashed,
  Clock,
  ShieldAlert,
  XCircle,
} from 'lucide-react';
import type { ActionPriority, ActionStatus, ReviewStatus } from '../types/governance';

export function ReviewStatusLabel({ status }: { status: ReviewStatus }) {
  switch (status) {
    case 'Approved':
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700 whitespace-nowrap">
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
          <span>Approved</span>
        </span>
      );
    case 'Rejected':
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-red-700 whitespace-nowrap">
          <XCircle className="w-3.5 h-3.5 text-red-600 shrink-0" />
          <span>Rejected</span>
        </span>
      );
    case 'Pending Specialist Review':
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-700 whitespace-nowrap">
          <ShieldAlert className="w-3.5 h-3.5 text-amber-600 shrink-0" />
          <span>Pending Specialist Review</span>
        </span>
      );
    case 'In Progress':
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-blue-700 whitespace-nowrap">
          <Clock className="w-3.5 h-3.5 text-blue-600 shrink-0" />
          <span>In Progress</span>
        </span>
      );
    case 'Not Started':
    default:
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-600 whitespace-nowrap">
          <CircleDashed className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <span>Not Started</span>
        </span>
      );
  }
}

export function ActionStatusLabel({ status }: { status: ActionStatus }) {
  switch (status) {
    case 'Completed':
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700 whitespace-nowrap">
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
          <span>Completed</span>
        </span>
      );
    case 'Blocked':
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-red-700 whitespace-nowrap">
          <AlertOctagon className="w-3.5 h-3.5 text-red-600 shrink-0" />
          <span>Blocked</span>
        </span>
      );
    case 'In Progress':
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-blue-700 whitespace-nowrap">
          <Clock className="w-3.5 h-3.5 text-blue-600 shrink-0" />
          <span>In Progress</span>
        </span>
      );
    case 'Open':
    default:
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-700 whitespace-nowrap">
          <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
          <span>Open</span>
        </span>
      );
  }
}

export function PriorityLabel({ priority }: { priority: ActionPriority }) {
  const colorMap: Record<ActionPriority, string> = {
    Critical: 'text-red-700 font-semibold',
    High: 'text-amber-700 font-semibold',
    Medium: 'text-slate-700 font-medium',
    Low: 'text-slate-500 font-medium',
  };
  return <span className={`text-xs whitespace-nowrap ${colorMap[priority]}`}>{priority}</span>;
}
