import { useState } from 'react';
import { ChevronDown, ChevronUp, Download, RotateCcw, Upload } from 'lucide-react';
import type { WorkbenchState } from '../types/governance';
import { downloadTextFile, formatIsoDateTime } from '../utils/reporting';
import { validateImportedWorkbenchJson } from '../utils/storage';

interface HistoryDataViewProps {
  state: WorkbenchState;
  onImportState: (nextState: WorkbenchState) => void;
  onResetBaseline: () => void;
}

export function HistoryDataView({
  state,
  onImportState,
  onResetBaseline,
}: HistoryDataViewProps) {
  const [filterSystemId, setFilterSystemId] = useState<string>('all');
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [importText, setImportText] = useState('');
  const [importStatus, setImportStatus] = useState<{
    type: 'error' | 'success';
    text: string;
  } | null>(null);

  const filteredHistory = state.history.filter(
    (entry) => filterSystemId === 'all' || entry.systemId === filterSystemId
  );

  const handleExportJson = () => {
    const filename = `eurofin-ai-governance-workbench-${new Date().toISOString().slice(0, 10)}.json`;
    downloadTextFile(filename, JSON.stringify(state, null, 2), 'application/json;charset=utf-8');
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const validated = validateImportedWorkbenchJson(text);
      onImportState(validated);
      setImportStatus({
        type: 'success',
        text: `Imported ${validated.systems.length} AI systems and ${validated.remediations.length} remediation actions from ${file.name}.`,
      });
    } catch (err) {
      setImportStatus({
        type: 'error',
        text: err instanceof Error ? err.message : 'Failed to parse imported JSON file.',
      });
    }
    e.target.value = '';
  };

  const handlePasteImport = () => {
    try {
      const validated = validateImportedWorkbenchJson(importText);
      onImportState(validated);
      setImportText('');
      setImportStatus({
        type: 'success',
        text: `Imported ${validated.systems.length} AI systems and ${validated.remediations.length} remediation actions.`,
      });
    } catch (err) {
      setImportStatus({
        type: 'error',
        text: err instanceof Error ? err.message : 'Invalid workbench JSON payload.',
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-slate-500">
            Versioned Audit Trail · Local Persistence & Demo Reset
          </p>
          <h2 className="mt-1 text-2xl font-semibold tracking-tight text-slate-900">
            Assessment History & Data Portability
          </h2>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={handleExportJson}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-white bg-blue-700 rounded-md hover:bg-blue-800 whitespace-nowrap cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Workbench JSON</span>
          </button>

          <button
            type="button"
            onClick={() => {
              onResetBaseline();
              setImportStatus({
                type: 'success',
                text: 'Restored EuroFin Services S.A. 15-system baseline (Not Started assessments & WBS tasks).',
              });
            }}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-md hover:bg-slate-50 whitespace-nowrap cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Demo Baseline</span>
          </button>
        </div>
      </div>

      {/* JSON Import Panel */}
      <section className="border border-slate-200 bg-white rounded-md p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">Import Workbench JSON</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Restore a previously exported JSON snapshot (systems, WBS schedule, business case, stakeholders, reviews, and history).
            </p>
          </div>
          <label className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-700 bg-slate-50 border border-slate-200 rounded-md hover:bg-slate-100 cursor-pointer shrink-0">
            <Upload className="w-3.5 h-3.5" />
            <span>Upload JSON File</span>
            <input
              type="file"
              accept=".json,application/json"
              onChange={handleFileUpload}
              className="sr-only"
            />
          </label>
        </div>

        {importStatus && (
          <div
            className={`p-3 rounded-md border text-xs font-medium ${
              importStatus.type === 'error'
                ? 'border-red-200 bg-red-50 text-red-800'
                : 'border-emerald-200 bg-emerald-50 text-emerald-800'
            }`}
          >
            {importStatus.text}
          </div>
        )}

        <div className="flex flex-col sm:flex-row gap-3">
          <textarea
            rows={2}
            value={importText}
            onChange={(e) => setImportText(e.target.value)}
            placeholder="Or paste exported workbench JSON here..."
            className="flex-1 px-3 py-2 text-xs font-mono bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
          />
          <button
            type="button"
            disabled={!importText.trim()}
            onClick={handlePasteImport}
            className="px-4 py-2 text-xs font-medium text-slate-800 bg-white border border-slate-200 rounded-md hover:bg-slate-50 disabled:opacity-50 self-end whitespace-nowrap cursor-pointer"
          >
            Import Pasted JSON
          </button>
        </div>
      </section>

      {/* Chronological History Log */}
      <section className="border border-slate-200 bg-white rounded-md">
        <div className="px-6 py-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">
              Audit & Assessment Version Log ({filteredHistory.length})
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Records every intake update, Gemini triage version, specialist review, WBS edit, and business case change
            </p>
          </div>
          <select
            aria-label="Filter history by AI system"
            value={filterSystemId}
            onChange={(e) => setFilterSystemId(e.target.value)}
            className="px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-md text-slate-800"
          >
            <option value="all">All Records & Programme Events</option>
            {state.systems.map((s) => (
              <option key={s.intake.id} value={s.intake.id}>
                {s.intake.systemCode} — {s.intake.name}
              </option>
            ))}
          </select>
        </div>

        <div className="divide-y divide-slate-200">
          {filteredHistory.length === 0 ? (
            <p className="p-8 text-center text-xs text-slate-500">
              No activity recorded yet. Edit an AI system intake, run a Gemini assessment, update a WBS work package, or record a specialist review to populate the audit trail.
            </p>
          ) : (
            filteredHistory.map((entry) => {
              const isExpanded = expandedId === entry.id;
              return (
                <div key={entry.id} className="px-6 py-4 space-y-2">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex flex-wrap items-center gap-2 text-xs">
                      <span className="font-mono text-slate-500">
                        {formatIsoDateTime(entry.timestamp)}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="font-semibold text-slate-900">{entry.eventType}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono text-blue-700">{entry.versionLabel}</span>
                      <span aria-hidden="true">·</span>
                      <span className="text-slate-600">{entry.actor}</span>
                    </div>

                    {entry.assessmentSnapshot && (
                      <button
                        type="button"
                        onClick={() => setExpandedId(isExpanded ? null : entry.id)}
                        className="inline-flex items-center gap-1 text-xs font-medium text-blue-700 hover:text-blue-800 cursor-pointer"
                      >
                        <span>{isExpanded ? 'Hide Snapshot' : 'View Version Snapshot'}</span>
                        {isExpanded ? (
                          <ChevronUp className="w-3.5 h-3.5" />
                        ) : (
                          <ChevronDown className="w-3.5 h-3.5" />
                        )}
                      </button>
                    )}
                  </div>

                  <p className="text-xs font-medium text-slate-800">
                    {entry.systemName} — {entry.summary}
                  </p>

                  {entry.changes.length > 0 && (
                    <ul className="text-xs text-slate-600 list-disc pl-4 space-y-0.5">
                      {entry.changes.map((c, idx) => (
                        <li key={idx}>{c}</li>
                      ))}
                    </ul>
                  )}

                  {isExpanded && entry.assessmentSnapshot && (
                    <div className="mt-3 p-4 bg-slate-50 border border-slate-200 rounded-md text-xs space-y-2">
                      <p className="font-semibold text-slate-900">
                        Assessment Snapshot (v{entry.assessmentSnapshot.version})
                      </p>
                      <p className="text-slate-700">{entry.assessmentSnapshot.executiveSummary}</p>
                      <p className="text-slate-600">
                        <strong>Indicators:</strong>{' '}
                        {entry.assessmentSnapshot.prohibitedPracticeIndicators.length} prohibited ·{' '}
                        {entry.assessmentSnapshot.highRiskIndicators.length} high-risk ·{' '}
                        {entry.assessmentSnapshot.missingInformation.length} missing info items
                      </p>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </section>
    </div>
  );
}
