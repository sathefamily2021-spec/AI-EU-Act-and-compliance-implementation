import { useState } from 'react';
import { Edit3, Save, Users } from 'lucide-react';
import type { StakeholderRoleEntry, WorkbenchState } from '../types/governance';

interface StakeholdersViewProps {
  state: WorkbenchState;
  onUpdateStakeholder: (updated: StakeholderRoleEntry) => void;
  onNavigate: (tab: string, systemId?: string) => void;
}

export function StakeholdersView({
  state,
  onUpdateStakeholder,
  onNavigate,
}: StakeholdersViewProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draftNotes, setDraftNotes] = useState('');
  const [draftCadence, setDraftCadence] = useState('');

  const getLinkedWbsIds = (roleTitle: string): string[] => {
    return state.wbsTasks
      .filter(
        (t) =>
          t.accountableOwner === roleTitle || t.supportingRoles.includes(roleTitle)
      )
      .map((t) => t.id);
  };

  const getLinkedSystemCodes = (roleTitle: string): string[] => {
    if (roleTitle === 'Business Owners') {
      return state.systems.map((s) => s.intake.systemCode);
    }
    if (roleTitle === 'Legal/Compliance' || roleTitle === 'DPO' || roleTitle === 'CISO') {
      return state.systems.map((s) => s.intake.systemCode);
    }
    return state.systems
      .filter((s) => s.intake.businessOwner === roleTitle)
      .map((s) => s.intake.systemCode);
  };

  const handleSave = (stk: StakeholderRoleEntry) => {
    onUpdateStakeholder({
      ...stk,
      engagementCadence: draftCadence.trim() || stk.engagementCadence,
      notes: draftNotes.trim(),
    });
    setEditingId(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-slate-500">
            Role-Based Governance Accountability · {state.organisationName}
          </p>
          <h2 className="mt-1 text-2xl font-semibold tracking-tight text-slate-900">
            Stakeholder & Ownership Directory
          </h2>
        </div>

        <div className="inline-flex items-center gap-2 text-xs text-slate-600">
          <Users className="w-4 h-4 text-slate-500" />
          <span className="font-mono tabular-nums">
            {state.stakeholders.length} Defined Governance Roles
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {state.stakeholders.map((stk) => {
          const linkedWbs = getLinkedWbsIds(stk.roleTitle);
          const linkedSystems = getLinkedSystemCodes(stk.roleTitle);
          const isEditing = editingId === stk.id;

          return (
            <section
              key={stk.id}
              className="border border-slate-200 bg-white rounded-md flex flex-col justify-between"
            >
              <div className="p-6 space-y-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="text-base font-semibold text-slate-900">{stk.roleTitle}</h3>
                    <p className="text-xs font-medium text-blue-700 mt-0.5">{stk.projectRole}</p>
                  </div>
                  {!isEditing ? (
                    <button
                      type="button"
                      onClick={() => {
                        setEditingId(stk.id);
                        setDraftCadence(stk.engagementCadence);
                        setDraftNotes(stk.notes);
                      }}
                      className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-700 border border-slate-200 rounded hover:bg-slate-50 cursor-pointer"
                    >
                      <Edit3 className="w-3 h-3" />
                      <span>Edit</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => handleSave(stk)}
                      className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-white bg-blue-700 rounded hover:bg-blue-800 cursor-pointer"
                    >
                      <Save className="w-3 h-3" />
                      <span>Save</span>
                    </button>
                  )}
                </div>

                <div className="space-y-2 text-xs">
                  <div>
                    <p className="font-semibold text-slate-700">Governance Responsibility</p>
                    <p className="text-slate-600 mt-0.5 leading-relaxed">
                      {stk.governanceResponsibility}
                    </p>
                  </div>
                  <div>
                    <p className="font-semibold text-slate-700">Decision Authority</p>
                    <p className="text-slate-600 mt-0.5">{stk.decisionAuthority}</p>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-200 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <p className="font-semibold text-slate-700">Linked WBS Work Packages</p>
                    <p className="font-mono text-slate-600 mt-0.5">
                      {linkedWbs.length > 0 ? linkedWbs.join(', ') : 'Oversight / Advisory'}
                    </p>
                  </div>
                  <div>
                    <p className="font-semibold text-slate-700">System Scope</p>
                    <p className="font-mono text-slate-600 mt-0.5">
                      {linkedSystems.length === state.systems.length
                        ? `All ${state.systems.length} AI systems`
                        : linkedSystems.length > 0
                        ? linkedSystems.join(', ')
                        : 'Programme-level'}
                    </p>
                  </div>
                </div>

                {isEditing ? (
                  <div className="pt-3 border-t border-slate-200 space-y-3 text-xs">
                    <div>
                      <label className="block font-medium text-slate-700 mb-1">
                        Engagement Cadence
                      </label>
                      <input
                        type="text"
                        value={draftCadence}
                        onChange={(e) => setDraftCadence(e.target.value)}
                        className="w-full px-3 py-1.5 border border-slate-200 rounded-md"
                      />
                    </div>
                    <div>
                      <label className="block font-medium text-slate-700 mb-1">Role Notes</label>
                      <textarea
                        rows={2}
                        value={draftNotes}
                        onChange={(e) => setDraftNotes(e.target.value)}
                        className="w-full px-3 py-1.5 border border-slate-200 rounded-md"
                      />
                    </div>
                  </div>
                ) : (
                  <div className="pt-3 border-t border-slate-200 text-xs text-slate-500 flex flex-wrap items-center justify-between gap-2">
                    <span>Cadence: {stk.engagementCadence}</span>
                    {stk.roleTitle === 'CISO' && (
                      <button
                        type="button"
                        onClick={() => onNavigate('intake', 'sys-014')}
                        className="text-blue-700 hover:text-blue-800 font-medium cursor-pointer"
                      >
                        Owns SYS-014 →
                      </button>
                    )}
                  </div>
                )}
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
}
