import {
  Download,
  Edit3,
  Play,
  ShieldAlert,
  UserCheck,
} from 'lucide-react';
import type { WorkbenchState } from '../types/governance';
import {
  downloadTextFile,
  formatIsoDateTime,
  generateSystemReportMarkdown,
} from '../utils/reporting';
import { isActionOverdue } from '../utils/storage';
import { ActionStatusLabel, PriorityLabel, ReviewStatusLabel } from './StatusText';

interface SystemDetailViewProps {
  state: WorkbenchState;
  selectedSystemId: string | null;
  onSelectSystem: (id: string) => void;
  onNavigate: (tab: string, systemId?: string) => void;
}

function fieldValue(val: string | undefined | null): string {
  if (!val || val.trim() === '') return 'Not provided';
  return val.trim();
}

export function SystemDetailView({
  state,
  selectedSystemId,
  onSelectSystem,
  onNavigate,
}: SystemDetailViewProps) {
  const activeSystem =
    state.systems.find((s) => s.intake.id === selectedSystemId) ?? state.systems[0] ?? null;

  if (!activeSystem) {
    return (
      <div className="border border-slate-200 bg-white rounded-md p-8 text-center text-xs text-slate-500">
        No AI systems registered yet.
      </div>
    );
  }

  const { intake, assessment, review } = activeSystem;
  const linkedRemediations = state.remediations.filter((r) => r.systemId === intake.id);
  const linkedHistory = state.history.filter((h) => h.systemId === intake.id);

  const handleExportReport = () => {
    const md = generateSystemReportMarkdown(
      activeSystem,
      state.remediations,
      state.history,
      state.organisationName
    );
    downloadTextFile(`${intake.systemCode.toLowerCase()}-governance-report.md`, md);
  };

  return (
    <div className="space-y-6">
      {/* Header & Direct Actions */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <span className="font-mono font-semibold text-slate-800">{intake.systemCode}</span>
            <span aria-hidden="true">·</span>
            <span>{fieldValue(intake.department)}</span>
            <span aria-hidden="true">·</span>
            <span>Owner: {fieldValue(intake.businessOwner)}</span>
          </div>
          <h2 className="mt-1 text-2xl font-semibold tracking-tight text-slate-900">
            {intake.name}
          </h2>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <select
            aria-label="Select AI system detail record"
            value={intake.id}
            onChange={(e) => onSelectSystem(e.target.value)}
            className="px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900"
          >
            {state.systems.map((s) => (
              <option key={s.intake.id} value={s.intake.id}>
                {s.intake.systemCode} — {s.intake.name}
              </option>
            ))}
          </select>

          <button
            type="button"
            onClick={() => onNavigate('intake', intake.id)}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-md hover:bg-slate-50 cursor-pointer"
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>Edit Intake</span>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('assessment', intake.id)}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-white bg-blue-700 rounded-md hover:bg-blue-800 cursor-pointer"
          >
            <Play className="w-3.5 h-3.5" />
            <span>{assessment ? 'View Assessment' : 'Run Assessment'}</span>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('review', intake.id)}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-md hover:bg-slate-50 cursor-pointer"
          >
            <UserCheck className="w-3.5 h-3.5" />
            <span>Human Review</span>
          </button>

          <button
            type="button"
            onClick={handleExportReport}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-800 bg-white border border-slate-200 rounded-md hover:bg-slate-50 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Report</span>
          </button>
        </div>
      </div>

      {/* Epistemic Distinction Banner */}
      <div className="border border-slate-200 bg-slate-50 rounded-md p-4 text-xs text-slate-700 space-y-1">
        <p className="font-semibold text-slate-900">
          Illustrative Assumptions vs. Evidence Required for Verification
        </p>
        <p>{fieldValue(intake.illustrativeAssumptionsNote)}</p>
      </div>

      {/* Saved Business Profile & Evidence Grid */}
      <div className="border border-slate-200 bg-white rounded-md grid grid-cols-1 lg:grid-cols-2 divide-y lg:divide-y-0 lg:divide-x divide-slate-200">
        <div className="p-6 space-y-4 text-xs">
          <h3 className="text-sm font-semibold text-slate-900">
            Saved System & Business Profile
          </h3>
          <dl className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <dt className="text-slate-500 font-medium">Department</dt>
              <dd className="mt-0.5 text-slate-900 font-medium">{fieldValue(intake.department)}</dd>
            </div>
            <div>
              <dt className="text-slate-500 font-medium">Business Owner Role</dt>
              <dd className="mt-0.5 text-slate-900 font-medium">{fieldValue(intake.businessOwner)}</dd>
            </div>
            <div className="sm:col-span-2">
              <dt className="text-slate-500 font-medium">Business Purpose</dt>
              <dd className="mt-0.5 text-slate-800">{fieldValue(intake.businessPurpose)}</dd>
            </div>
            <div className="sm:col-span-2">
              <dt className="text-slate-500 font-medium">Business Process</dt>
              <dd className="mt-0.5 text-slate-800">{fieldValue(intake.businessProcess)}</dd>
            </div>
            <div className="sm:col-span-2">
              <dt className="text-slate-500 font-medium">Provider / Deployer Role</dt>
              <dd className="mt-0.5 text-slate-800">{fieldValue(intake.role)}</dd>
            </div>
            <div className="sm:col-span-2">
              <dt className="text-slate-500 font-medium">Intended Users</dt>
              <dd className="mt-0.5 text-slate-800">{fieldValue(intake.intendedUsers)}</dd>
            </div>
            <div className="sm:col-span-2">
              <dt className="text-slate-500 font-medium">Potential Data Categories</dt>
              <dd className="mt-0.5 text-slate-800">{fieldValue(intake.dataTypesProcessed)}</dd>
            </div>
            <div>
              <dt className="text-slate-500 font-medium">Personal / Special Data</dt>
              <dd className="mt-0.5 text-slate-800">
                Personal: {intake.personalDataInvolved} · Special: {intake.specialCategoryDataInvolved}
              </dd>
            </div>
            <div>
              <dt className="text-slate-500 font-medium">Sensitive Decisions</dt>
              <dd className="mt-0.5 text-slate-800">{intake.affectsSensitiveDecisions}</dd>
            </div>
          </dl>
        </div>

        <div className="p-6 space-y-4 text-xs">
          <h3 className="text-sm font-semibold text-slate-900">
            Evidence, Supplier, Oversight & Specialist Reviewers
          </h3>
          <dl className="space-y-3">
            <div>
              <dt className="text-slate-500 font-medium">Confirmed Evidence Available ({intake.evidenceStatus})</dt>
              <dd className="mt-0.5 text-slate-800">{fieldValue(intake.supportingEvidence)}</dd>
            </div>
            <div>
              <dt className="text-slate-500 font-medium">Evidence Required for Verification</dt>
              <dd className="mt-0.5 text-slate-800">{fieldValue(intake.evidenceRequired)}</dd>
            </div>
            <div>
              <dt className="text-slate-500 font-medium">Supplier Information (Provisional)</dt>
              <dd className="mt-0.5 text-slate-800">{fieldValue(intake.supplierInformation)}</dd>
            </div>
            <div>
              <dt className="text-slate-500 font-medium">Human Oversight Arrangements (Provisional)</dt>
              <dd className="mt-0.5 text-slate-800">{fieldValue(intake.humanOversightArrangements)}</dd>
            </div>
          </dl>

          <div className="pt-4 border-t border-slate-200 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-900">Assigned Specialist Reviewers</span>
              <ReviewStatusLabel status={review.overallStatus} />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {Object.values(review.areas).map((area) => (
                <div key={area.domain} className="p-2.5 bg-slate-50 border border-slate-200 rounded">
                  <p className="font-semibold text-slate-800">{area.label}</p>
                  <p className="text-slate-600 mt-0.5">{fieldValue(area.reviewerName)}</p>
                  <p className="text-[11px] text-slate-500 mt-0.5">Status: {area.status}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Preliminary Assessment Status */}
      <section className="border border-slate-200 bg-white rounded-md p-6 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="text-sm font-semibold text-slate-900">
            Preliminary AI Governance Assessment
          </h3>
          <span className="text-xs font-mono text-slate-500">
            {assessment
              ? `Completed v${assessment.version} · ${formatIsoDateTime(assessment.generatedAt)}`
              : 'Assessment Not Started'}
          </span>
        </div>

        {!assessment ? (
          <p className="text-xs text-slate-600">
            Assessment Not Started. No AI-generated risk triage has been run for {intake.systemCode} yet.
          </p>
        ) : (
          <div className="space-y-3 text-xs">
            <p className="text-slate-700 leading-relaxed">{assessment.executiveSummary}</p>
            <div className="flex flex-wrap gap-4 font-mono text-slate-700">
              <span>
                Prohibited Indicators: {assessment.prohibitedPracticeIndicators.length}
              </span>
              <span>
                High-Risk Indicators: {assessment.highRiskIndicators.length}
              </span>
              <span>Missing Info Gaps: {assessment.missingInformation.length}</span>
            </div>
            {(assessment.prohibitedPracticeIndicators.length > 0 ||
              assessment.highRiskIndicators.length > 0) && (
              <p className="text-amber-800 font-medium inline-flex items-center gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5" />
                <span>Specialist Legal/Compliance review required on flagged indicators.</span>
              </p>
            )}
          </div>
        )}
      </section>

      {/* Linked Outstanding Actions & Audit Trail */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <section className="border border-slate-200 bg-white rounded-md">
          <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-900">
              Outstanding & Linked Actions ({linkedRemediations.length})
            </h3>
            <button
              type="button"
              onClick={() => onNavigate('remediation')}
              className="text-xs font-medium text-blue-700 hover:text-blue-800 cursor-pointer"
            >
              Manage in Tracker →
            </button>
          </div>
          <div className="divide-y divide-slate-200">
            {linkedRemediations.length === 0 ? (
              <p className="p-6 text-xs text-slate-500">No remediation actions linked to this system.</p>
            ) : (
              linkedRemediations.map((act) => (
                <div key={act.id} className="px-6 py-3.5 space-y-1 text-xs">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono text-slate-500">
                      Due {act.dueDate}
                      {isActionOverdue(act) ? ' (OVERDUE)' : ''}
                    </span>
                    <div className="flex items-center gap-2">
                      <PriorityLabel priority={act.priority} />
                      <ActionStatusLabel status={act.status} />
                    </div>
                  </div>
                  <p className="font-semibold text-slate-900">{act.title}</p>
                  <p className="text-slate-500">Owner: {act.owner}</p>
                </div>
              ))
            )}
          </div>
        </section>

        <section className="border border-slate-200 bg-white rounded-md">
          <div className="px-6 py-4 border-b border-slate-200">
            <h3 className="text-sm font-semibold text-slate-900">
              System Audit History ({linkedHistory.length})
            </h3>
          </div>
          <div className="divide-y divide-slate-200 max-h-72 overflow-y-auto">
            {linkedHistory.length === 0 ? (
              <p className="p-6 text-xs text-slate-500">
                No modifications or assessments recorded for this system yet.
              </p>
            ) : (
              linkedHistory.map((h) => (
                <div key={h.id} className="px-6 py-3 text-xs space-y-0.5">
                  <div className="flex items-center gap-2 text-slate-500">
                    <span className="font-mono">{formatIsoDateTime(h.timestamp)}</span>
                    <span>·</span>
                    <span className="font-semibold text-slate-800">{h.eventType}</span>
                  </div>
                  <p className="text-slate-700">{h.summary}</p>
                </div>
              ))
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
