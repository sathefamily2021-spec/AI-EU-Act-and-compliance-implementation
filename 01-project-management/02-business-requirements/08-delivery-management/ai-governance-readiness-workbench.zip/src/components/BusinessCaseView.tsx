import { useState } from 'react';
import { ArrowRight, CheckCircle2, Clock, Edit3, Save, ShieldAlert } from 'lucide-react';
import type { BusinessCaseData, WorkbenchState } from '../types/governance';
import { computeBusinessCaseMetrics } from '../utils/reporting';
import { computeWbsSchedule } from '../utils/wbs';

interface BusinessCaseViewProps {
  state: WorkbenchState;
  onUpdateBusinessCase: (updated: BusinessCaseData) => void;
  onNavigate: (tab: string, systemId?: string) => void;
}

export function BusinessCaseView({
  state,
  onUpdateBusinessCase,
  onNavigate,
}: BusinessCaseViewProps) {
  const bc = state.businessCase;
  const metrics = computeBusinessCaseMetrics(state, 7);
  const wbs = computeWbsSchedule(state.wbsTasks);
  const budgetTotal = bc.budgetBreakdown.reduce((sum, item) => sum + item.amountEur, 0);

  const [isEditingNarrative, setIsEditingNarrative] = useState(false);
  const [problemDraft, setProblemDraft] = useState(bc.businessProblem);
  const [objectiveDraft, setObjectiveDraft] = useState(bc.projectObjective);

  const handleSaveNarrative = () => {
    onUpdateBusinessCase({
      ...bc,
      businessProblem: problemDraft.trim() || bc.businessProblem,
      projectObjective: objectiveDraft.trim() || bc.projectObjective,
    });
    setIsEditingNarrative(false);
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-slate-500">
            {bc.organisation} · {bc.industry} · {bc.employees.toLocaleString()} Employees
          </p>
          <h2 className="mt-1 text-2xl font-semibold tracking-tight text-slate-900">
            Project Business Case & Success Measures
          </h2>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => onNavigate('wbs')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-md hover:bg-slate-50 whitespace-nowrap cursor-pointer"
          >
            <span>Open WBS Schedule</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => onNavigate('stakeholders')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-white bg-blue-700 rounded-md hover:bg-blue-800 whitespace-nowrap cursor-pointer"
          >
            <span>Stakeholder Directory</span>
          </button>
        </div>
      </div>

      {/* Executive Parameters Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 border border-slate-200 bg-white rounded-md divide-y sm:divide-y-0 sm:divide-x divide-slate-200">
        <div className="p-4">
          <p className="text-xs text-slate-500">Organisation</p>
          <p className="mt-1 text-sm font-semibold text-slate-900">{bc.organisation}</p>
          <p className="mt-0.5 text-xs text-slate-500 tabular-nums">
            {bc.employees.toLocaleString()} employees
          </p>
        </div>

        <div className="p-4">
          <p className="text-xs text-slate-500">AI Systems in Scope</p>
          <p className="mt-1 text-lg font-semibold text-slate-900 font-mono tabular-nums">
            {bc.aiSystemsInScope}
          </p>
          <p className="mt-0.5 text-xs text-slate-500 tabular-nums">
            {metrics.inventoryCount} in register
          </p>
        </div>

        <div className="p-4">
          <p className="text-xs text-slate-500">Project Duration</p>
          <p className="mt-1 text-lg font-semibold text-slate-900 font-mono tabular-nums">
            {bc.projectDurationWeeks} weeks
          </p>
          <p className="mt-0.5 text-xs text-slate-500 font-mono tabular-nums">
            {wbs.projectDurationDays} working days
          </p>
        </div>

        <div className="p-4">
          <p className="text-xs text-slate-500">Illustrative Budget</p>
          <p className="mt-1 text-lg font-semibold text-slate-900 font-mono tabular-nums">
            EUR {bc.illustrativeBudgetEur.toLocaleString()}
          </p>
          <p className="mt-0.5 text-xs text-slate-500">Illustrative baseline</p>
        </div>

        <div className="p-4">
          <p className="text-xs text-slate-500">Delivery Method</p>
          <p className="mt-1 text-sm font-semibold text-slate-900">{bc.deliveryMethod}</p>
          <p className="mt-0.5 text-xs text-slate-500">5-day calendar, FS CPM</p>
        </div>

        <div className="p-4">
          <p className="text-xs text-slate-500">Governance Leadership</p>
          <p className="mt-1 text-xs font-semibold text-slate-900">Sponsor: {bc.projectSponsor}</p>
          <p className="mt-0.5 text-xs text-slate-600">
            Lead: {bc.businessLead} · {bc.projectManager}
          </p>
        </div>
      </div>

      {/* Problem Statement & Objective */}
      <section className="border border-slate-200 bg-white rounded-md">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between gap-4">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">
              Business Problem & Project Objective
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Core rationale for central AI governance readiness at {bc.organisation}
            </p>
          </div>
          {!isEditingNarrative ? (
            <button
              type="button"
              onClick={() => {
                setProblemDraft(bc.businessProblem);
                setObjectiveDraft(bc.projectObjective);
                setIsEditingNarrative(true);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-md hover:bg-slate-50 cursor-pointer"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Edit Case Statement</span>
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsEditingNarrative(false)}
                className="px-3 py-1.5 text-xs font-medium text-slate-600 border border-slate-200 rounded-md hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveNarrative}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-blue-700 rounded-md hover:bg-blue-800 cursor-pointer"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Save</span>
              </button>
            </div>
          )}
        </div>

        <div className="p-6 grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-2">
            <h4 className="text-xs font-semibold text-slate-900">Business Problem</h4>
            {isEditingNarrative ? (
              <textarea
                rows={4}
                value={problemDraft}
                onChange={(e) => setProblemDraft(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-md text-slate-900"
              />
            ) : (
              <p className="text-xs text-slate-700 leading-relaxed">{bc.businessProblem}</p>
            )}
          </div>

          <div className="space-y-2">
            <h4 className="text-xs font-semibold text-slate-900">Project Objective</h4>
            {isEditingNarrative ? (
              <textarea
                rows={4}
                value={objectiveDraft}
                onChange={(e) => setObjectiveDraft(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-200 rounded-md text-slate-900"
              />
            ) : (
              <p className="text-xs text-slate-700 leading-relaxed">{bc.projectObjective}</p>
            )}
          </div>
        </div>
      </section>

      {/* Success Measures: Targets vs Live Achieved Results */}
      <section className="border border-slate-200 bg-white rounded-md overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">
              Success Measures: Targets vs. Achieved Results
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Achieved results are calculated live from the 15-system Register, Evidence Traceability, Human Review, and Evaluation Suite
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('evaluation')}
            className="text-xs font-medium text-blue-700 hover:text-blue-800 whitespace-nowrap cursor-pointer"
          >
            Open Evaluation Tests →
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                <th className="py-3 px-4">Success Measure</th>
                <th className="py-3 px-4">Baseline Target</th>
                <th className="py-3 px-4">Live Achieved Result</th>
                <th className="py-3 px-4">Linked Requirement / WBS</th>
                <th className="py-3 px-4 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-xs">
              {metrics.measures.map((m) => (
                <tr key={m.id} className="hover:bg-slate-50/70">
                  <td className="py-3.5 px-4 font-semibold text-slate-900">{m.metricName}</td>
                  <td className="py-3.5 px-4 text-slate-700">{m.targetDescription}</td>
                  <td className="py-3.5 px-4 font-mono tabular-nums text-slate-900">
                    {m.achievedDisplay}
                  </td>
                  <td className="py-3.5 px-4 font-mono text-slate-600 whitespace-nowrap">
                    {m.linkedRequirement}
                  </td>
                  <td className="py-3.5 px-4 text-right whitespace-nowrap">
                    {m.statusLabel === 'Target Met' && (
                      <span className="inline-flex items-center gap-1.5 font-medium text-emerald-700">
                        <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                        <span>Target Met</span>
                      </span>
                    )}
                    {m.statusLabel === 'In Progress' && (
                      <span className="inline-flex items-center gap-1.5 font-medium text-amber-700">
                        <Clock className="w-3.5 h-3.5 shrink-0" />
                        <span>In Progress</span>
                      </span>
                    )}
                    {m.statusLabel === 'Not Yet Tested' && (
                      <span className="inline-flex items-center gap-1.5 font-medium text-slate-500">
                        <ShieldAlert className="w-3.5 h-3.5 shrink-0" />
                        <span>Not Yet Tested</span>
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Scope / Out-of-Scope & Assumptions / Dependencies / Benefits */}
      <div className="border border-slate-200 bg-white rounded-md grid grid-cols-1 lg:grid-cols-2 divide-y lg:divide-y-0 lg:divide-x divide-slate-200">
        <div className="p-6 space-y-6">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">In Scope (8-Week Readiness Phase)</h3>
            <ul className="mt-2.5 space-y-1.5 text-xs text-slate-700 list-disc pl-4">
              {bc.inScope.map((item, idx) => (
                <li key={idx}>{item}</li>
              ))}
            </ul>
          </div>
          <div className="pt-5 border-t border-slate-200">
            <h3 className="text-sm font-semibold text-slate-900">Explicitly Out of Scope</h3>
            <ul className="mt-2.5 space-y-1.5 text-xs text-slate-600 list-disc pl-4">
              {bc.outOfScope.map((item, idx) => (
                <li key={idx}>{item}</li>
              ))}
            </ul>
          </div>
        </div>

        <div className="p-6 space-y-6">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">Key Assumptions</h3>
            <ul className="mt-2.5 space-y-1.5 text-xs text-slate-700 list-disc pl-4">
              {bc.assumptions.map((item, idx) => (
                <li key={idx}>{item}</li>
              ))}
            </ul>
          </div>
          <div className="pt-5 border-t border-slate-200">
            <h3 className="text-sm font-semibold text-slate-900">Dependencies</h3>
            <ul className="mt-2.5 space-y-1.5 text-xs text-slate-700 list-disc pl-4">
              {bc.dependencies.map((item, idx) => (
                <li key={idx}>{item}</li>
              ))}
            </ul>
          </div>
          <div className="pt-5 border-t border-slate-200">
            <h3 className="text-sm font-semibold text-slate-900">Expected Organisational Benefits</h3>
            <ul className="mt-2.5 space-y-1.5 text-xs text-slate-700 list-disc pl-4">
              {bc.benefits.map((item, idx) => (
                <li key={idx}>{item}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Illustrative Budget & Stakeholder Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <section className="lg:col-span-7 border border-slate-200 bg-white rounded-md overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-semibold text-slate-900">
                Illustrative Project Budget Allocation
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Finance role oversight across the 8-week Hybrid Agile/Waterfall delivery
              </p>
            </div>
            <span className="text-sm font-semibold font-mono tabular-nums text-slate-900">
              EUR {budgetTotal.toLocaleString()}
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 font-semibold text-slate-600">
                  <th className="py-2.5 px-4">Workstream / Cost Category</th>
                  <th className="py-2.5 px-4">Owner Role</th>
                  <th className="py-2.5 px-4 text-right">Illustrative EUR</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {bc.budgetBreakdown.map((row, idx) => (
                  <tr key={idx}>
                    <td className="py-3 px-4">
                      <p className="font-medium text-slate-900">{row.category}</p>
                      <p className="text-slate-500 mt-0.5">{row.notes}</p>
                    </td>
                    <td className="py-3 px-4 text-slate-700 whitespace-nowrap">{row.ownerRole}</td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-900 whitespace-nowrap">
                      EUR {row.amountEur.toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section className="lg:col-span-5 border border-slate-200 bg-white rounded-md">
          <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-semibold text-slate-900">
                Key Governance Stakeholders ({state.stakeholders.length})
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">Role-based accountability model</p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('stakeholders')}
              className="text-xs font-medium text-blue-700 hover:text-blue-800 cursor-pointer"
            >
              Full Directory →
            </button>
          </div>
          <div className="divide-y divide-slate-200 max-h-96 overflow-y-auto">
            {state.stakeholders.map((stk) => (
              <div key={stk.id} className="px-6 py-3 flex items-center justify-between gap-3 text-xs">
                <span className="font-semibold text-slate-900">{stk.roleTitle}</span>
                <span className="text-slate-600 text-right">{stk.projectRole}</span>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
