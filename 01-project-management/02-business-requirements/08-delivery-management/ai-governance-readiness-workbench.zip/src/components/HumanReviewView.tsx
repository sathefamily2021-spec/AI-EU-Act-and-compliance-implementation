import { useEffect, useState } from 'react';
import { FileText, Lock, Save, ShieldCheck } from 'lucide-react';
import type {
  AISystemRecord,
  RemediationAction,
  ReviewStatus,
  SpecialistDomain,
} from '../types/governance';
import { formatIsoDateTime } from '../utils/reporting';
import { ReviewStatusLabel } from './StatusText';

interface HumanReviewViewProps {
  systems: AISystemRecord[];
  remediations: RemediationAction[];
  selectedSystemId: string | null;
  onSelectSystem: (id: string) => void;
  onUpdateSpecialistArea: (
    systemId: string,
    domain: SpecialistDomain,
    status: ReviewStatus,
    reviewerName: string,
    rationale: string
  ) => void;
  onUpdateOverallStatus: (
    systemId: string,
    overallStatus: ReviewStatus,
    reviewerName: string,
    rationale: string
  ) => void;
}

const STATUS_OPTIONS: ReviewStatus[] = [
  'Not Started',
  'In Progress',
  'Pending Specialist Review',
  'Approved',
  'Rejected',
];

const SPECIALIST_DOMAINS: SpecialistDomain[] = [
  'legalCompliance',
  'dpo',
  'cisoSecurity',
  'businessOwner',
];

export function HumanReviewView({
  systems,
  remediations,
  selectedSystemId,
  onSelectSystem,
  onUpdateSpecialistArea,
  onUpdateOverallStatus,
}: HumanReviewViewProps) {
  const activeSystem =
    systems.find((s) => s.intake.id === selectedSystemId) ?? systems[0] ?? null;

  const [areaDrafts, setAreaDrafts] = useState<
    Record<SpecialistDomain, { status: ReviewStatus; reviewerName: string; rationale: string }>
  >({
    legalCompliance: { status: 'Not Started', reviewerName: '', rationale: '' },
    dpo: { status: 'Not Started', reviewerName: '', rationale: '' },
    cisoSecurity: { status: 'Not Started', reviewerName: '', rationale: '' },
    businessOwner: { status: 'Not Started', reviewerName: '', rationale: '' },
  });

  const [overallDraft, setOverallDraft] = useState<{
    status: ReviewStatus;
    reviewerName: string;
    rationale: string;
  }>({
    status: 'Not Started',
    reviewerName: '',
    rationale: '',
  });

  const [feedback, setFeedback] = useState<{ type: 'error' | 'success'; text: string } | null>(
    null
  );

  useEffect(() => {
    if (!activeSystem) return;
    setAreaDrafts({
      legalCompliance: {
        status: activeSystem.review.areas.legalCompliance.status,
        reviewerName: activeSystem.review.areas.legalCompliance.reviewerName,
        rationale: activeSystem.review.areas.legalCompliance.rationale,
      },
      dpo: {
        status: activeSystem.review.areas.dpo.status,
        reviewerName: activeSystem.review.areas.dpo.reviewerName,
        rationale: activeSystem.review.areas.dpo.rationale,
      },
      cisoSecurity: {
        status: activeSystem.review.areas.cisoSecurity.status,
        reviewerName: activeSystem.review.areas.cisoSecurity.reviewerName,
        rationale: activeSystem.review.areas.cisoSecurity.rationale,
      },
      businessOwner: {
        status: activeSystem.review.areas.businessOwner.status,
        reviewerName: activeSystem.review.areas.businessOwner.reviewerName,
        rationale: activeSystem.review.areas.businessOwner.rationale,
      },
    });
    setOverallDraft({
      status: activeSystem.review.overallStatus,
      reviewerName: activeSystem.review.finalDecisionBy,
      rationale: activeSystem.review.finalDecisionRationale,
    });
    setFeedback(null);
  }, [activeSystem]);

  if (!activeSystem) {
    return (
      <div className="border border-slate-200 bg-white rounded-md p-8 text-center text-xs text-slate-500">
        No AI systems registered yet.
      </div>
    );
  }

  const linkedRemediations = remediations.filter(
    (r) => r.systemId === activeSystem.intake.id
  );

  const handleSaveArea = (domain: SpecialistDomain) => {
    const draft = areaDrafts[domain];
    if ((draft.status === 'Approved' || draft.status === 'Rejected') && !draft.reviewerName.trim()) {
      setFeedback({
        type: 'error',
        text: 'Reviewer role/identifier is required before recording an Approved or Rejected sign-off.',
      });
      return;
    }
    onUpdateSpecialistArea(
      activeSystem.intake.id,
      domain,
      draft.status,
      draft.reviewerName.trim(),
      draft.rationale.trim()
    );
    setFeedback({
      type: 'success',
      text: `Saved ${activeSystem.review.areas[domain].label} review status (${draft.status}).`,
    });
  };

  const handleSaveOverall = () => {
    if (
      (overallDraft.status === 'Approved' || overallDraft.status === 'Rejected') &&
      (!overallDraft.reviewerName.trim() || !overallDraft.rationale.trim())
    ) {
      setFeedback({
        type: 'error',
        text: 'Final human approval or rejection requires both a decision authority role and a documented rationale.',
      });
      return;
    }

    if (overallDraft.status === 'Approved') {
      const anyRejected = Object.values(activeSystem.review.areas).some(
        (a) => a.status === 'Rejected'
      );
      if (anyRejected) {
        setFeedback({
          type: 'error',
          text: 'Cannot set overall status to Approved while one or more specialist areas are Rejected.',
        });
        return;
      }
      const allApproved = Object.values(activeSystem.review.areas).every(
        (a) => a.status === 'Approved'
      );
      if (!allApproved) {
        setFeedback({
          type: 'error',
          text: 'All four specialist areas (Legal/Compliance, DPO, CISO/Security, Business Owner) must be Approved before overall Approval.',
        });
        return;
      }
    }

    onUpdateOverallStatus(
      activeSystem.intake.id,
      overallDraft.status,
      overallDraft.reviewerName.trim(),
      overallDraft.rationale.trim()
    );
    setFeedback({
      type: 'success',
      text: `Updated overall human review status to ${overallDraft.status}.`,
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-slate-500">
            Specialist Governance Gates · Linked to System Evidence & Actions
          </p>
          <h2 className="mt-1 text-2xl font-semibold tracking-tight text-slate-900">
            Human Review Workflow
          </h2>
        </div>

        <select
          aria-label="Select AI system for human review"
          value={activeSystem.intake.id}
          onChange={(e) => onSelectSystem(e.target.value)}
          className="px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
        >
          {systems.map((s) => (
            <option key={s.intake.id} value={s.intake.id}>
              {s.intake.systemCode} — {s.intake.name}
            </option>
          ))}
        </select>
      </div>

      {/* Mandatory Authority Safeguard Notice */}
      <div className="border border-slate-200 bg-slate-50 rounded-md px-5 py-3.5 flex items-start gap-3 text-xs text-slate-700">
        <Lock className="w-4 h-4 text-slate-600 shrink-0 mt-0.5" />
        <div>
          <p className="font-semibold text-slate-900">
            Human Specialist Authority Safeguard Active
          </p>
          <p className="mt-0.5 text-slate-600">
            AI triage outputs cannot approve systems, reject proposals, or issue final legal classifications. Final sign-off requires qualified human review across Legal/Compliance, DPO, CISO/Security, and Business Owner.
          </p>
        </div>
      </div>

      {/* Linked System Evidence & Remediation Context */}
      <div className="border border-slate-200 bg-white rounded-md p-5 grid grid-cols-1 md:grid-cols-3 gap-5 text-xs">
        <div>
          <p className="font-semibold text-slate-900 flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5 text-slate-500" />
            <span>Linked System & Role</span>
          </p>
          <p className="mt-1 text-slate-800 font-medium">
            {activeSystem.intake.systemCode} · {activeSystem.intake.name}
          </p>
          <p className="text-slate-500 mt-0.5">
            Dept: {activeSystem.intake.department} · Role: {activeSystem.intake.role}
          </p>
        </div>

        <div>
          <p className="font-semibold text-slate-900">Linked Evidence Status</p>
          <p className="mt-1 font-medium text-slate-800">
            Status: {activeSystem.intake.evidenceStatus}
          </p>
          <p className="text-slate-500 mt-0.5">
            {activeSystem.intake.supportingEvidence || 'No supporting evidence attached yet.'}
          </p>
        </div>

        <div>
          <p className="font-semibold text-slate-900">Linked Remediation & AI Triage</p>
          <p className="mt-1 font-mono text-slate-800">
            {linkedRemediations.filter((r) => r.status !== 'Completed').length} open action(s) ·{' '}
            {activeSystem.assessment
              ? `AI Triage v${activeSystem.assessment.version}`
              : 'AI Triage Not Started'}
          </p>
          <p className="text-slate-500 mt-0.5">
            Data categories: {activeSystem.intake.dataTypesProcessed}
          </p>
        </div>
      </div>

      {feedback && (
        <div
          className={`p-4 rounded-md border text-xs font-medium ${
            feedback.type === 'error'
              ? 'border-red-200 bg-red-50 text-red-800'
              : 'border-emerald-200 bg-emerald-50 text-emerald-800'
          }`}
        >
          {feedback.text}
        </div>
      )}

      {/* Four Specialist Review Areas */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {SPECIALIST_DOMAINS.map((domain) => {
          const area = activeSystem.review.areas[domain];
          const draft = areaDrafts[domain];
          return (
            <section
              key={domain}
              className="border border-slate-200 bg-white rounded-md flex flex-col justify-between"
            >
              <div className="p-6 space-y-4">
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <h3 className="text-sm font-semibold text-slate-900">{area.label}</h3>
                    <p className="text-[11px] text-slate-500 mt-0.5 font-mono">
                      Last updated: {formatIsoDateTime(area.updatedAt)}
                    </p>
                  </div>
                  <ReviewStatusLabel status={area.status} />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Area Status
                    </label>
                    <select
                      value={draft.status}
                      onChange={(e) =>
                        setAreaDrafts((prev) => ({
                          ...prev,
                          [domain]: {
                            ...prev[domain],
                            status: e.target.value as ReviewStatus,
                          },
                        }))
                      }
                      className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                    >
                      {STATUS_OPTIONS.map((opt) => (
                        <option key={opt} value={opt}>
                          {opt}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Assigned Reviewer Role
                    </label>
                    <input
                      type="text"
                      value={draft.reviewerName}
                      onChange={(e) =>
                        setAreaDrafts((prev) => ({
                          ...prev,
                          [domain]: { ...prev[domain], reviewerName: e.target.value },
                        }))
                      }
                      placeholder="Role title (e.g., Legal/Compliance)"
                      className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Review Rationale / Evidence Conditions
                  </label>
                  <textarea
                    rows={3}
                    value={draft.rationale}
                    onChange={(e) =>
                      setAreaDrafts((prev) => ({
                        ...prev,
                        [domain]: { ...prev[domain], rationale: e.target.value },
                      }))
                    }
                    placeholder="Document legal classification notes, DPIA conditions, security controls, or evidence gaps..."
                    className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                </div>
              </div>

              <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex justify-end">
                <button
                  type="button"
                  onClick={() => handleSaveArea(domain)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-slate-800 bg-white border border-slate-200 rounded-md hover:bg-slate-100 cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save {area.label} Sign-Off</span>
                </button>
              </div>
            </section>
          );
        })}
      </div>

      {/* Overall Governance Determination */}
      <section className="border border-slate-200 bg-white rounded-md">
        <div className="px-6 py-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-blue-700" />
            <h3 className="text-sm font-semibold text-slate-900">
              Overall Governance Review Determination
            </h3>
          </div>
          <ReviewStatusLabel status={activeSystem.review.overallStatus} />
        </div>

        <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-5">
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1.5">
              Overall System Status
            </label>
            <select
              value={overallDraft.status}
              onChange={(e) =>
                setOverallDraft((prev) => ({
                  ...prev,
                  status: e.target.value as ReviewStatus,
                }))
              }
              className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
            >
              {STATUS_OPTIONS.map((opt) => (
                <option key={opt} value={opt}>
                  {opt}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1.5">
              Decision Authority (Role)
            </label>
            <input
              type="text"
              value={overallDraft.reviewerName}
              onChange={(e) =>
                setOverallDraft((prev) => ({ ...prev, reviewerName: e.target.value }))
              }
              placeholder="e.g., AI Governance Lead / Legal/Compliance"
              className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1.5">
              Last Final Decision Timestamp
            </label>
            <p className="px-3 py-2 text-xs font-mono text-slate-600 bg-slate-50 border border-slate-200 rounded-md">
              {formatIsoDateTime(activeSystem.review.finalDecisionAt)}
            </p>
          </div>

          <div className="md:col-span-3">
            <label className="block text-xs font-medium text-slate-700 mb-1.5">
              Final Governance Decision Rationale & Scope Conditions
            </label>
            <textarea
              rows={2}
              value={overallDraft.rationale}
              onChange={(e) =>
                setOverallDraft((prev) => ({ ...prev, rationale: e.target.value }))
              }
              placeholder="Record overall governance decision, deployment conditions, or escalation requirements..."
              className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
          </div>
        </div>

        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-4">
          <p className="text-xs text-slate-500">
            Overall Approved status requires all four specialist review areas to be Approved.
          </p>
          <button
            type="button"
            onClick={handleSaveOverall}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-blue-700 rounded-md hover:bg-blue-800 whitespace-nowrap cursor-pointer"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Record Overall Decision</span>
          </button>
        </div>
      </section>
    </div>
  );
}
