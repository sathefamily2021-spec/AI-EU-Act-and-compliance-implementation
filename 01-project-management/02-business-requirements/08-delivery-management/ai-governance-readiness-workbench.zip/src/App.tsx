import { useEffect, useState } from 'react';
import {
  BriefcaseBusiness,
  CalendarRange,
  CheckSquare,
  ClipboardList,
  Database,
  FileBarChart,
  FilePlus2,
  FileText,
  FlaskConical,
  History,
  LayoutDashboard,
  Menu,
  RotateCcw,
  Scale,
  ShieldCheck,
  UserCheck,
  Users,
  X,
} from 'lucide-react';
import { createEmptyReviewRecord } from './data/seedData';
import type {
  ActionPriority,
  ActionStatus,
  AISystemIntake,
  AISystemRecord,
  BusinessCaseData,
  EvaluationRunRecord,
  GovernanceAssessmentResult,
  HistoryEntry,
  RecommendedActionSuggestion,
  RemediationAction,
  ReviewStatus,
  SpecialistDomain,
  StakeholderRoleEntry,
  WbsTaskInput,
  WorkbenchState,
} from './types/governance';
import {
  getTodayIsoDate,
  loadWorkbenchState,
  resetWorkbenchState,
  saveWorkbenchState,
} from './utils/storage';
import { DashboardView } from './components/DashboardView';
import { RegisterView } from './components/RegisterView';
import { IntakeFormView } from './components/IntakeFormView';
import { AssessmentView } from './components/AssessmentView';
import { HumanReviewView } from './components/HumanReviewView';
import { RemediationView } from './components/RemediationView';
import { HistoryDataView } from './components/HistoryDataView';
import { ReportingView } from './components/ReportingView';
import { EvaluationView } from './components/EvaluationView';
import { BusinessCaseView } from './components/BusinessCaseView';
import { WbsDeliveryView } from './components/WbsDeliveryView';
import { StakeholdersView } from './components/StakeholdersView';
import { SystemDetailView } from './components/SystemDetailView';

type NavTabId =
  | 'dashboard'
  | 'business-case'
  | 'wbs'
  | 'stakeholders'
  | 'register'
  | 'detail'
  | 'intake'
  | 'assessment'
  | 'review'
  | 'remediation'
  | 'history'
  | 'reporting'
  | 'evaluation';

const NAV_ITEMS: Array<{
  id: NavTabId;
  label: string;
  breadcrumb: string;
  icon: React.ComponentType<{ className?: string }>;
}> = [
  { id: 'dashboard', label: 'Dashboard', breadcrumb: 'EuroFin / Dashboard', icon: LayoutDashboard },
  { id: 'business-case', label: 'Business Case', breadcrumb: 'Programme / Business Case', icon: BriefcaseBusiness },
  { id: 'wbs', label: 'WBS & Delivery', breadcrumb: 'Programme / WBS Schedule', icon: CalendarRange },
  { id: 'stakeholders', label: 'Stakeholders', breadcrumb: 'Programme / Ownership Directory', icon: Users },
  { id: 'register', label: 'AI System Register', breadcrumb: 'Inventory / 15-System Register', icon: Database },
  { id: 'detail', label: 'System Detail', breadcrumb: 'Inventory / System Detail', icon: FileText },
  { id: 'intake', label: 'AI System Intake', breadcrumb: 'Inventory / Intake Record', icon: FilePlus2 },
  { id: 'assessment', label: 'AI Assessment', breadcrumb: 'Triage / Gemini Analysis', icon: Scale },
  { id: 'review', label: 'Human Review', breadcrumb: 'Governance / Specialist Sign-Off', icon: UserCheck },
  { id: 'remediation', label: 'Remediation Tracker', breadcrumb: 'Actions / Remediation', icon: CheckSquare },
  { id: 'history', label: 'Assessment History', breadcrumb: 'Audit / History & JSON', icon: History },
  { id: 'reporting', label: 'Reporting', breadcrumb: 'Outputs / Governance Reports', icon: FileBarChart },
  { id: 'evaluation', label: 'Evaluation Mode', breadcrumb: 'Validation / Test Scenarios', icon: FlaskConical },
];

export default function App() {
  const [state, setState] = useState<WorkbenchState>(() => loadWorkbenchState());
  const [activeTab, setActiveTab] = useState<NavTabId>('dashboard');
  const [selectedSystemId, setSelectedSystemId] = useState<string | null>(
    () => loadWorkbenchState().systems[0]?.intake.id ?? null
  );
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isAssessing, setIsAssessing] = useState(false);
  const [assessmentError, setAssessmentError] = useState<string | null>(null);

  useEffect(() => {
    saveWorkbenchState(state);
  }, [state]);

  const handleNavigate = (tab: string, systemId?: string) => {
    const validTab = NAV_ITEMS.some((item) => item.id === tab)
      ? (tab as NavTabId)
      : 'dashboard';
    setActiveTab(validTab);
    if (systemId !== undefined) {
      setSelectedSystemId(systemId);
    } else if (validTab === 'intake') {
      setSelectedSystemId(null);
    }
    setAssessmentError(null);
    setMobileMenuOpen(false);
  };

  const handleRunAssessment = async (
    systemId: string,
    overrideRecord?: AISystemRecord
  ) => {
    const targetRecord =
      overrideRecord ?? state.systems.find((s) => s.intake.id === systemId);
    if (!targetRecord) return;

    setIsAssessing(true);
    setAssessmentError(null);

    try {
      const nextVersion = (targetRecord.assessment?.version ?? 0) + 1;
      const response = await fetch('/api/assessments/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          system: targetRecord.intake,
          nextVersion,
        }),
      });

      const data = (await response.json()) as {
        assessment?: GovernanceAssessmentResult;
        error?: string;
      };

      if (!response.ok || !data.assessment) {
        setAssessmentError(
          data.error || `Server returned status ${response.status} during Gemini assessment.`
        );
        return;
      }

      const newAssessment = data.assessment;

      setState((prev) => {
        const updatedSystems = prev.systems.map((sys) => {
          if (sys.intake.id !== systemId) return sys;
          const previousVersions = sys.assessment
            ? [...sys.assessmentVersions, sys.assessment]
            : sys.assessmentVersions;

          const nextOverallStatus: ReviewStatus =
            sys.review.overallStatus === 'Not Started'
              ? 'Pending Specialist Review'
              : sys.review.overallStatus;

          return {
            ...sys,
            assessment: newAssessment,
            assessmentVersions: previousVersions,
            review: {
              ...sys.review,
              overallStatus: nextOverallStatus,
            },
          };
        });

        const historyEntry: HistoryEntry = {
          id: `hist-${Date.now()}`,
          systemId,
          systemName: targetRecord.intake.name,
          timestamp: newAssessment.generatedAt,
          actor: `AI Governance Triage (${newAssessment.modelUsed})`,
          eventType: 'Assessment Generated',
          versionLabel: `v${newAssessment.version}`,
          summary: `Generated structured triage v${newAssessment.version}; flagged ${newAssessment.prohibitedPracticeIndicators.length} prohibited, ${newAssessment.highRiskIndicators.length} high-risk, and ${newAssessment.missingInformation.length} missing info items.`,
          changes: [
            `Prohibited indicators: ${newAssessment.prohibitedPracticeIndicators.length}`,
            `High-risk indicators: ${newAssessment.highRiskIndicators.length}`,
            `Missing information gaps: ${newAssessment.missingInformation.length}`,
          ],
          assessmentSnapshot: newAssessment,
        };

        return {
          ...prev,
          systems: updatedSystems,
          history: [historyEntry, ...prev.history],
        };
      });
    } catch (err) {
      setAssessmentError(
        err instanceof Error ? err.message : 'Network error calling assessment API.'
      );
    } finally {
      setIsAssessing(false);
    }
  };

  const handleSaveIntake = (
    draft: Omit<AISystemIntake, 'id' | 'systemCode' | 'createdAt' | 'updatedAt'>,
    existingId: string | null,
    runAssessmentAfterSave: boolean
  ) => {
    const now = new Date().toISOString();
    let targetRecord: AISystemRecord | null = null;
    let targetId = existingId;

    setState((prev) => {
      if (existingId) {
        const updatedSystems = prev.systems.map((sys) => {
          if (sys.intake.id !== existingId) return sys;
          const prevOwner = sys.intake.businessOwner;
          const currentOwnerReviewer = sys.review.areas.businessOwner.reviewerName;
          const shouldSyncOwnerReviewer =
            !currentOwnerReviewer ||
            currentOwnerReviewer === prevOwner ||
            currentOwnerReviewer === 'Business Owner';

          const updated: AISystemRecord = {
            ...sys,
            intake: {
              ...sys.intake,
              ...draft,
              updatedAt: now,
            },
            review: shouldSyncOwnerReviewer
              ? {
                  ...sys.review,
                  areas: {
                    ...sys.review.areas,
                    businessOwner: {
                      ...sys.review.areas.businessOwner,
                      reviewerName: draft.businessOwner || 'Business Owner',
                    },
                  },
                }
              : sys.review,
          };
          targetRecord = updated;
          return updated;
        });

        const historyEntry: HistoryEntry = {
          id: `hist-${Date.now()}`,
          systemId: existingId,
          systemName: draft.name,
          timestamp: now,
          actor: draft.businessOwner || 'Business Owner',
          eventType: 'Intake Updated',
          versionLabel: 'Intake',
          summary: `Updated intake details for ${draft.name}.`,
          changes: [
            `Department: ${draft.department || 'To Be Confirmed'}`,
            `Role: ${draft.role}`,
            `Evidence status: ${draft.evidenceStatus}`,
          ],
        };

        return {
          ...prev,
          systems: updatedSystems,
          history: [historyEntry, ...prev.history],
        };
      } else {
        const nextNum = prev.systems.length + 1;
        const systemCode = `SYS-${String(nextNum).padStart(3, '0')}`;
        const newId = `sys-${Date.now()}`;
        targetId = newId;

        const created: AISystemRecord = {
          intake: {
            ...draft,
            id: newId,
            systemCode,
            createdAt: now,
            updatedAt: now,
          },
          assessment: null,
          assessmentVersions: [],
          review: createEmptyReviewRecord(draft.businessOwner || 'Business Owner'),
        };
        targetRecord = created;

        const historyEntry: HistoryEntry = {
          id: `hist-${Date.now()}`,
          systemId: newId,
          systemName: draft.name,
          timestamp: now,
          actor: draft.businessOwner || 'Business Owner',
          eventType: 'Intake Created',
          versionLabel: systemCode,
          summary: `Registered new AI system intake ${systemCode} (${draft.name}).`,
          changes: [`Created record ${systemCode}`, `Role: ${draft.role}`],
        };

        return {
          ...prev,
          systems: [...prev.systems, created],
          history: [historyEntry, ...prev.history],
        };
      }
    });

    if (targetId) {
      setSelectedSystemId(targetId);
    }

    if (runAssessmentAfterSave && targetId && targetRecord) {
      setActiveTab('assessment');
      void handleRunAssessment(targetId, targetRecord);
    }
  };

  const handleUpdateSpecialistArea = (
    systemId: string,
    domain: SpecialistDomain,
    status: ReviewStatus,
    reviewerName: string,
    rationale: string
  ) => {
    const now = new Date().toISOString();
    setState((prev) => {
      let sysName = '';
      let areaLabel = '';
      const updatedSystems = prev.systems.map((sys) => {
        if (sys.intake.id !== systemId) return sys;
        sysName = sys.intake.name;
        areaLabel = sys.review.areas[domain].label;
        return {
          ...sys,
          review: {
            ...sys.review,
            areas: {
              ...sys.review.areas,
              [domain]: {
                ...sys.review.areas[domain],
                status,
                reviewerName,
                rationale,
                updatedAt: now,
              },
            },
          },
        };
      });

      const historyEntry: HistoryEntry = {
        id: `hist-${Date.now()}`,
        systemId,
        systemName: sysName,
        timestamp: now,
        actor: reviewerName || areaLabel,
        eventType: 'Specialist Review Updated',
        versionLabel: 'Review',
        summary: `${areaLabel} updated to ${status}.`,
        changes: [
          `Area: ${areaLabel} -> ${status}`,
          ...(rationale ? [`Rationale: ${rationale}`] : []),
        ],
      };

      return {
        ...prev,
        systems: updatedSystems,
        history: [historyEntry, ...prev.history],
      };
    });
  };

  const handleUpdateOverallStatus = (
    systemId: string,
    overallStatus: ReviewStatus,
    reviewerName: string,
    rationale: string
  ) => {
    const now = new Date().toISOString();
    setState((prev) => {
      let sysName = '';
      const updatedSystems = prev.systems.map((sys) => {
        if (sys.intake.id !== systemId) return sys;
        sysName = sys.intake.name;
        return {
          ...sys,
          review: {
            ...sys.review,
            overallStatus,
            finalDecisionBy: reviewerName,
            finalDecisionRationale: rationale,
            finalDecisionAt: now,
          },
        };
      });

      const historyEntry: HistoryEntry = {
        id: `hist-${Date.now()}`,
        systemId,
        systemName: sysName,
        timestamp: now,
        actor: reviewerName || 'AI Governance Lead',
        eventType: 'Overall Status Updated',
        versionLabel: 'Decision',
        summary: `Overall human review status set to ${overallStatus}.`,
        changes: [
          `Overall status -> ${overallStatus}`,
          ...(rationale ? [`Decision rationale: ${rationale}`] : []),
        ],
      };

      return {
        ...prev,
        systems: updatedSystems,
        history: [historyEntry, ...prev.history],
      };
    });
  };

  const handleCreateRemediation = (
    action: Omit<RemediationAction, 'id' | 'createdAt' | 'updatedAt'>
  ) => {
    const now = new Date().toISOString();
    const sys = state.systems.find((s) => s.intake.id === action.systemId);
    const created: RemediationAction = {
      ...action,
      id: `rem-${Date.now()}`,
      createdAt: now,
      updatedAt: now,
    };
    const historyEntry: HistoryEntry = {
      id: `hist-${Date.now()}`,
      systemId: action.systemId,
      systemName: sys?.intake.name ?? 'System',
      timestamp: now,
      actor: action.owner,
      eventType: 'Remediation Updated',
      versionLabel: 'Action',
      summary: `Created remediation action "${action.title}" (Due ${action.dueDate}).`,
      changes: [`Priority: ${action.priority}`, `Owner: ${action.owner}`],
    };
    setState((prev) => ({
      ...prev,
      remediations: [created, ...prev.remediations],
      history: [historyEntry, ...prev.history],
    }));
  };

  const handleAddRemediationFromSuggestion = (
    systemId: string,
    suggestion: RecommendedActionSuggestion
  ) => {
    const due = new Date();
    due.setDate(due.getDate() + 14);
    const dueIso = due.toISOString().slice(0, 10);
    const priorityMap: Record<RecommendedActionSuggestion['priority'], ActionPriority> = {
      High: 'High',
      Medium: 'Medium',
      Low: 'Low',
    };
    handleCreateRemediation({
      systemId,
      title: suggestion.title,
      description: suggestion.rationale,
      owner: suggestion.ownerRole,
      dueDate: dueIso || getTodayIsoDate(),
      priority: priorityMap[suggestion.priority],
      status: 'Open',
      source: 'AI Assessment',
    });
  };

  const handleUpdateRemediationStatus = (actionId: string, status: ActionStatus) => {
    const now = new Date().toISOString();
    setState((prev) => ({
      ...prev,
      remediations: prev.remediations.map((r) =>
        r.id === actionId ? { ...r, status, updatedAt: now } : r
      ),
    }));
  };

  const handleDeleteRemediation = (actionId: string) => {
    setState((prev) => ({
      ...prev,
      remediations: prev.remediations.filter((r) => r.id !== actionId),
    }));
  };

  const handleUpdateWbsTask = (updatedTask: WbsTaskInput) => {
    const now = new Date().toISOString();
    setState((prev) => {
      const historyEntry: HistoryEntry = {
        id: `hist-${Date.now()}`,
        systemId: 'programme-wbs',
        systemName: 'WBS Project Delivery',
        timestamp: now,
        actor: 'Project Manager',
        eventType: 'WBS Updated',
        versionLabel: updatedTask.id,
        summary: `Updated ${updatedTask.id} (${updatedTask.name}) — ${updatedTask.status} (${updatedTask.actualProgress}%).`,
        changes: [
          `Duration: ${updatedTask.durationDays}d`,
          `Status: ${updatedTask.status}`,
          `Actual Progress: ${updatedTask.actualProgress}%`,
        ],
      };
      return {
        ...prev,
        wbsTasks: prev.wbsTasks.map((t) => (t.id === updatedTask.id ? updatedTask : t)),
        history: [historyEntry, ...prev.history],
      };
    });
  };

  const handleUpdateBusinessCase = (updated: BusinessCaseData) => {
    const now = new Date().toISOString();
    setState((prev) => ({
      ...prev,
      businessCase: updated,
      history: [
        {
          id: `hist-${Date.now()}`,
          systemId: 'programme-bc',
          systemName: 'Project Business Case',
          timestamp: now,
          actor: 'AI Governance Lead',
          eventType: 'Business Case Updated',
          versionLabel: 'Case',
          summary: 'Updated Project Business Case problem statement and objective.',
          changes: ['Modified Business Problem / Project Objective'],
        },
        ...prev.history,
      ],
    }));
  };

  const handleUpdateStakeholder = (updated: StakeholderRoleEntry) => {
    const now = new Date().toISOString();
    setState((prev) => ({
      ...prev,
      stakeholders: prev.stakeholders.map((s) => (s.id === updated.id ? updated : s)),
      history: [
        {
          id: `hist-${Date.now()}`,
          systemId: 'programme-stakeholders',
          systemName: 'Stakeholder Directory',
          timestamp: now,
          actor: 'Project Manager',
          eventType: 'Stakeholder Updated',
          versionLabel: updated.roleTitle,
          summary: `Updated engagement notes for ${updated.roleTitle}.`,
          changes: [`Cadence: ${updated.engagementCadence}`],
        },
        ...prev.history,
      ],
    }));
  };

  const handleImportState = (imported: WorkbenchState) => {
    const now = new Date().toISOString();
    const historyEntry: HistoryEntry = {
      id: `hist-${Date.now()}`,
      systemId: imported.systems[0]?.intake.id ?? 'portfolio',
      systemName: 'Portfolio Workbench',
      timestamp: now,
      actor: 'Workbench User',
      eventType: 'Data Imported',
      versionLabel: 'Import',
      summary: `Imported JSON snapshot (${imported.systems.length} systems, ${imported.remediations.length} actions).`,
      changes: ['Replaced local state from JSON import'],
    };
    setState({
      ...imported,
      history: [historyEntry, ...imported.history],
    });
    setSelectedSystemId(imported.systems[0]?.intake.id ?? null);
  };

  const handleResetBaseline = () => {
    const fresh = resetWorkbenchState();
    setState(fresh);
    setSelectedSystemId(fresh.systems[0]?.intake.id ?? null);
  };

  const handleSaveEvaluationRun = (record: EvaluationRunRecord) => {
    setState((prev) => ({
      ...prev,
      evaluations: {
        ...prev.evaluations,
        [record.scenarioId]: record,
      },
    }));
  };

  const currentNavMeta = NAV_ITEMS.find((i) => i.id === activeTab) ?? NAV_ITEMS[0];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:fixed lg:inset-y-0 bg-slate-900 text-slate-100 border-r border-slate-800">
        <div className="px-5 py-5 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-5 h-5 text-blue-400 shrink-0" />
            <span className="text-sm font-semibold tracking-tight text-white">
              AI Governance Workbench
            </span>
          </div>
          <p className="mt-1.5 text-[11px] text-slate-400">
            {state.organisationName} · 15 Systems
          </p>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto" aria-label="Primary">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleNavigate(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-blue-700 text-white'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="px-5 py-4 border-t border-slate-800 text-[11px] text-slate-400 space-y-2">
          <button
            type="button"
            onClick={handleResetBaseline}
            className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-[11px] font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 rounded transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset EuroFin Demo Data</span>
          </button>
          <p className="leading-relaxed">
            Decision-support prototype. Synthetic data only. Qualified human reviewers retain final approval and legal classification.
          </p>
        </div>
      </aside>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-950/50"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative z-10 w-64 max-w-full bg-slate-900 text-slate-100 flex flex-col h-full">
            <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
              <span className="text-sm font-semibold text-white">
                AI Governance Workbench
              </span>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                aria-label="Close navigation"
                className="p-1.5 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
              {NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleNavigate(item.id)}
                    className={`w-full flex items-center gap-3 px-3 py-2 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                      isActive
                        ? 'bg-blue-700 text-white'
                        : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
          </aside>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        {/* Top Bar Contract: Breadcrumb Left — Primary Action Right */}
        <header className="sticky top-0 z-30 bg-white border-b border-slate-200 px-4 sm:px-8 h-14 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              aria-label="Open navigation menu"
              className="lg:hidden p-2 -ml-2 text-slate-600 hover:text-slate-900 cursor-pointer"
            >
              <Menu className="w-5 h-5" />
            </button>
            <span className="text-xs font-medium text-slate-500 truncate">
              {currentNavMeta.breadcrumb}
            </span>
          </div>

          <button
            type="button"
            onClick={() => handleNavigate('intake')}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white bg-blue-700 rounded-md hover:bg-blue-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <ClipboardList className="w-3.5 h-3.5" />
            <span>New Intake</span>
          </button>
        </header>

        {/* Governance Notice Bar */}
        <div className="bg-slate-100 border-b border-slate-200 px-4 sm:px-8 py-2 text-[11px] text-slate-600 flex flex-wrap items-center justify-between gap-2">
          <span>
            {state.organisationName} · Decision-support prototype using synthetic data only · Not legal advice or compliance certification.
          </span>
          <span className="font-mono text-slate-500">
            Human Specialists Retain Final Authority
          </span>
        </div>

        {/* Viewport Container */}
        <main className="flex-1 px-4 sm:px-8 py-6 max-w-[1360px] w-full mx-auto">
          {activeTab === 'dashboard' && (
            <DashboardView state={state} onNavigate={handleNavigate} />
          )}

          {activeTab === 'business-case' && (
            <BusinessCaseView
              state={state}
              onUpdateBusinessCase={handleUpdateBusinessCase}
              onNavigate={handleNavigate}
            />
          )}

          {activeTab === 'wbs' && (
            <WbsDeliveryView
              wbsTasks={state.wbsTasks}
              onUpdateTask={handleUpdateWbsTask}
            />
          )}

          {activeTab === 'stakeholders' && (
            <StakeholdersView
              state={state}
              onUpdateStakeholder={handleUpdateStakeholder}
              onNavigate={handleNavigate}
            />
          )}

          {activeTab === 'register' && (
            <RegisterView state={state} onNavigate={handleNavigate} />
          )}

          {activeTab === 'detail' && (
            <SystemDetailView
              state={state}
              selectedSystemId={selectedSystemId}
              onSelectSystem={(id) => setSelectedSystemId(id)}
              onNavigate={handleNavigate}
            />
          )}

          {activeTab === 'intake' && (
            <IntakeFormView
              systems={state.systems}
              selectedSystemId={selectedSystemId}
              onSelectSystem={setSelectedSystemId}
              onSaveIntake={handleSaveIntake}
            />
          )}

          {activeTab === 'assessment' && (
            <AssessmentView
              systems={state.systems}
              remediations={state.remediations}
              history={state.history}
              organisationName={state.organisationName}
              selectedSystemId={selectedSystemId}
              onSelectSystem={(id) => setSelectedSystemId(id)}
              onRunAssessment={(id) => handleRunAssessment(id)}
              isAssessing={isAssessing}
              assessmentError={assessmentError}
              onAddRemediationFromSuggestion={handleAddRemediationFromSuggestion}
              onNavigate={handleNavigate}
            />
          )}

          {activeTab === 'review' && (
            <HumanReviewView
              systems={state.systems}
              remediations={state.remediations}
              selectedSystemId={selectedSystemId}
              onSelectSystem={(id) => setSelectedSystemId(id)}
              onUpdateSpecialistArea={handleUpdateSpecialistArea}
              onUpdateOverallStatus={handleUpdateOverallStatus}
            />
          )}

          {activeTab === 'remediation' && (
            <RemediationView
              systems={state.systems}
              remediations={state.remediations}
              onCreateAction={handleCreateRemediation}
              onUpdateActionStatus={handleUpdateRemediationStatus}
              onDeleteAction={handleDeleteRemediation}
            />
          )}

          {activeTab === 'history' && (
            <HistoryDataView
              state={state}
              onImportState={handleImportState}
              onResetBaseline={handleResetBaseline}
            />
          )}

          {activeTab === 'reporting' && (
            <ReportingView
              state={state}
              selectedSystemId={selectedSystemId}
              onSelectSystem={(id) => setSelectedSystemId(id)}
            />
          )}

          {activeTab === 'evaluation' && (
            <EvaluationView
              evaluations={state.evaluations}
              onSaveEvaluationRun={handleSaveEvaluationRun}
            />
          )}
        </main>
      </div>
    </div>
  );
}
