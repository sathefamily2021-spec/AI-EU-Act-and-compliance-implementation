import {
  EUROFIN_BUSINESS_CASE,
  EUROFIN_STAKEHOLDERS,
  EUROFIN_WBS_TASKS,
  INITIAL_REMEDIATIONS,
  INITIAL_SYSTEM_RECORDS,
  INITIAL_WORKBENCH_STATE,
} from '../data/seedData';
import type { AISystemRecord, RemediationAction, WorkbenchState } from '../types/governance';

const STORAGE_KEY = 'eurofin_ai_governance_workbench_v2';
const LEGACY_V1_KEY = 'ai_governance_workbench_v1';

export function getTodayIsoDate(): string {
  return new Date().toISOString().slice(0, 10);
}

export function isActionOverdue(action: RemediationAction): boolean {
  if (action.status === 'Completed') return false;
  if (!action.dueDate) return false;
  return action.dueDate < getTodayIsoDate();
}

function isUnpopulatedPlaceholder(val: string | undefined | null): boolean {
  if (!val) return true;
  const trimmed = val.trim();
  if (!trimmed) return true;
  if (trimmed === 'To Be Confirmed') return true;
  if (trimmed.includes('(technical scope To Be Confirmed)')) return true;
  return false;
}

function upgradeSystemRecordFromSeed(sys: AISystemRecord): AISystemRecord {
  const seedMatch = INITIAL_SYSTEM_RECORDS.find((s) => s.intake.id === sys.intake.id);
  if (!seedMatch) {
    return {
      ...sys,
      intake: {
        ...sys.intake,
        department: sys.intake.department || '',
        businessProcess: sys.intake.businessProcess || '',
        evidenceRequired: sys.intake.evidenceRequired || '',
        illustrativeAssumptionsNote: sys.intake.illustrativeAssumptionsNote || '',
        evidenceStatus: sys.intake.evidenceStatus || 'Not Provided',
      },
    };
  }

  const i = sys.intake;
  const si = seedMatch.intake;

  // Preserve any user-edited values; only populate fields that were still unpopulated placeholders or missing in v2
  const upgradedIntake = {
    ...i,
    department: isUnpopulatedPlaceholder(i.department) ? si.department : i.department,
    businessPurpose: isUnpopulatedPlaceholder(i.businessPurpose)
      ? si.businessPurpose
      : i.businessPurpose,
    businessProcess: isUnpopulatedPlaceholder(i.businessProcess)
      ? si.businessProcess
      : i.businessProcess,
    businessOwner: isUnpopulatedPlaceholder(i.businessOwner) ? si.businessOwner : i.businessOwner,
    role: i.role === 'To Be Confirmed' ? si.role : i.role,
    intendedUsers: isUnpopulatedPlaceholder(i.intendedUsers) ? si.intendedUsers : i.intendedUsers,
    countryOfDeployment: isUnpopulatedPlaceholder(i.countryOfDeployment)
      ? si.countryOfDeployment
      : i.countryOfDeployment,
    aiFunctionality: isUnpopulatedPlaceholder(i.aiFunctionality)
      ? si.aiFunctionality
      : i.aiFunctionality,
    dataTypesProcessed: isUnpopulatedPlaceholder(i.dataTypesProcessed)
      ? si.dataTypesProcessed
      : i.dataTypesProcessed,
    personalDataInvolved:
      i.personalDataInvolved === 'Unclear' && si.personalDataInvolved !== 'Unclear'
        ? si.personalDataInvolved
        : i.personalDataInvolved,
    sensitiveDecisionDetails: isUnpopulatedPlaceholder(i.sensitiveDecisionDetails)
      ? si.sensitiveDecisionDetails
      : i.sensitiveDecisionDetails,
    supplierInformation: isUnpopulatedPlaceholder(i.supplierInformation)
      ? si.supplierInformation
      : i.supplierInformation,
    humanOversightArrangements: isUnpopulatedPlaceholder(i.humanOversightArrangements)
      ? si.humanOversightArrangements
      : i.humanOversightArrangements,
    evidenceRequired: i.evidenceRequired ? i.evidenceRequired : si.evidenceRequired,
    illustrativeAssumptionsNote: i.illustrativeAssumptionsNote
      ? i.illustrativeAssumptionsNote
      : si.illustrativeAssumptionsNote,
    evidenceStatus: i.evidenceStatus || 'Not Provided',
  };

  // Ensure specialist reviewer role labels are populated if blank
  const areas = { ...sys.review.areas };
  if (!areas.legalCompliance.reviewerName || areas.legalCompliance.reviewerName === 'Legal/Compliance') {
    areas.legalCompliance = {
      ...areas.legalCompliance,
      reviewerName: seedMatch.review.areas.legalCompliance.reviewerName,
    };
  }
  if (!areas.dpo.reviewerName) {
    areas.dpo = { ...areas.dpo, reviewerName: seedMatch.review.areas.dpo.reviewerName };
  }
  if (!areas.cisoSecurity.reviewerName) {
    areas.cisoSecurity = {
      ...areas.cisoSecurity,
      reviewerName: seedMatch.review.areas.cisoSecurity.reviewerName,
    };
  }
  if (!areas.businessOwner.reviewerName) {
    areas.businessOwner = {
      ...areas.businessOwner,
      reviewerName: upgradedIntake.businessOwner || 'Business Owner',
    };
  }

  return {
    ...sys,
    intake: upgradedIntake,
    review: {
      ...sys.review,
      areas,
    },
  };
}

export function hydrateStateWithDefaults(parsed: Partial<WorkbenchState>): WorkbenchState {
  const needsV3SeedUpgrade = (parsed.seedVersion ?? 0) < 3;

  const rawSystems = Array.isArray(parsed.systems)
    ? parsed.systems
    : structuredClone(INITIAL_SYSTEM_RECORDS);

  const systems = needsV3SeedUpgrade
    ? rawSystems.map(upgradeSystemRecordFromSeed)
    : rawSystems.map((sys) => ({
        ...sys,
        intake: {
          ...sys.intake,
          department: sys.intake.department || '',
          businessProcess: sys.intake.businessProcess || '',
          evidenceRequired: sys.intake.evidenceRequired || '',
          illustrativeAssumptionsNote: sys.intake.illustrativeAssumptionsNote || '',
          evidenceStatus: sys.intake.evidenceStatus || 'Not Provided',
        },
      }));

  let remediations = Array.isArray(parsed.remediations) ? parsed.remediations : [];
  if (needsV3SeedUpgrade && remediations.length === 0) {
    remediations = structuredClone(INITIAL_REMEDIATIONS);
  }

  return {
    organisationName:
      typeof parsed.organisationName === 'string' && parsed.organisationName
        ? parsed.organisationName
        : INITIAL_WORKBENCH_STATE.organisationName,
    seedVersion: 3,
    systems,
    remediations,
    history: Array.isArray(parsed.history) ? parsed.history : [],
    evaluations:
      parsed.evaluations && typeof parsed.evaluations === 'object' ? parsed.evaluations : {},
    businessCase:
      parsed.businessCase && typeof parsed.businessCase === 'object'
        ? { ...structuredClone(EUROFIN_BUSINESS_CASE), ...parsed.businessCase }
        : structuredClone(EUROFIN_BUSINESS_CASE),
    wbsTasks:
      Array.isArray(parsed.wbsTasks) && parsed.wbsTasks.length > 0
        ? parsed.wbsTasks
        : structuredClone(EUROFIN_WBS_TASKS),
    stakeholders:
      Array.isArray(parsed.stakeholders) && parsed.stakeholders.length > 0
        ? parsed.stakeholders
        : structuredClone(EUROFIN_STAKEHOLDERS),
  };
}

export function loadWorkbenchState(): WorkbenchState {
  try {
    const rawV2 = window.localStorage.getItem(STORAGE_KEY);
    if (rawV2) {
      const parsed = JSON.parse(rawV2) as Partial<WorkbenchState>;
      if (parsed && Array.isArray(parsed.systems)) {
        const hydrated = hydrateStateWithDefaults(parsed);
        if ((parsed.seedVersion ?? 0) < 3) {
          saveWorkbenchState(hydrated);
        }
        return hydrated;
      }
    }

    const rawV1 = window.localStorage.getItem(LEGACY_V1_KEY);
    if (rawV1) {
      const parsedV1 = JSON.parse(rawV1) as Partial<WorkbenchState>;
      const base = structuredClone(INITIAL_WORKBENCH_STATE);
      if (parsedV1 && Array.isArray(parsedV1.systems)) {
        const legacySeedIds = new Set(['sys-001', 'sys-002', 'sys-003', 'sys-004']);
        const customSystems = parsedV1.systems
          .filter((s) => s?.intake?.id && !legacySeedIds.has(s.intake.id))
          .map(upgradeSystemRecordFromSeed);
        if (customSystems.length > 0) {
          base.systems = [...base.systems, ...customSystems];
        }
      }
      if (parsedV1?.evaluations && typeof parsedV1.evaluations === 'object') {
        base.evaluations = parsedV1.evaluations;
      }
      saveWorkbenchState(base);
      return base;
    }

    const fresh = structuredClone(INITIAL_WORKBENCH_STATE);
    saveWorkbenchState(fresh);
    return fresh;
  } catch {
    return structuredClone(INITIAL_WORKBENCH_STATE);
  }
}

export function saveWorkbenchState(state: WorkbenchState): void {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify({ ...state, seedVersion: 3 }));
  } catch (err) {
    console.error('Failed to persist workbench state to localStorage:', err);
  }
}

export function resetWorkbenchState(): WorkbenchState {
  const fresh = structuredClone(INITIAL_WORKBENCH_STATE);
  saveWorkbenchState(fresh);
  return fresh;
}

export function validateImportedWorkbenchJson(jsonText: string): WorkbenchState {
  const parsed = JSON.parse(jsonText) as Partial<WorkbenchState>;
  if (!parsed || typeof parsed !== 'object') {
    throw new Error('JSON root must be an object.');
  }
  if (!Array.isArray(parsed.systems)) {
    throw new Error('Imported JSON is missing a valid "systems" array.');
  }
  if (!Array.isArray(parsed.remediations)) {
    throw new Error('Imported JSON is missing a valid "remediations" array.');
  }
  for (const sys of parsed.systems) {
    if (!sys?.intake?.id || !sys?.intake?.name || !sys?.review?.areas) {
      throw new Error('One or more AI system records are malformed.');
    }
  }
  return hydrateStateWithDefaults(parsed);
}
