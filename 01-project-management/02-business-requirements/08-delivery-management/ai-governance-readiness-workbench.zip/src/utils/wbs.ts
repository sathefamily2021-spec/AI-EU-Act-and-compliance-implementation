import type { ComputedWbsTask, WbsTaskInput } from '../types/governance';

export interface WbsScheduleSummary {
  tasks: ComputedWbsTask[];
  projectDurationDays: number;
  criticalPathIds: string[];
  overallActualProgress: number;
  completedCount: number;
  inProgressCount: number;
  blockedCount: number;
  notStartedCount: number;
}

/**
 * Calculates Finish-to-Start (FS) Critical Path Method schedule on a 5-working-day calendar
 * with no resource levelling. Day 1 is the first working day of the project.
 */
export function computeWbsSchedule(inputs: WbsTaskInput[]): WbsScheduleSummary {
  const byId = new Map<string, WbsTaskInput>();
  for (const t of inputs) {
    byId.set(t.id, t);
  }

  // Forward pass (topological order via memoization with cycle guard)
  const earlyStart = new Map<string, number>();
  const earlyFinish = new Map<string, number>();
  const visiting = new Set<string>();

  function resolveForward(id: string): { es: number; ef: number } {
    if (earlyStart.has(id) && earlyFinish.has(id)) {
      return { es: earlyStart.get(id)!, ef: earlyFinish.get(id)! };
    }
    const task = byId.get(id);
    if (!task) return { es: 1, ef: 1 };
    if (visiting.has(id)) return { es: 1, ef: Math.max(1, task.durationDays) };
    visiting.add(id);

    let es = 1;
    for (const predId of task.predecessors) {
      if (!byId.has(predId)) continue;
      const pred = resolveForward(predId);
      if (pred.ef + 1 > es) {
        es = pred.ef + 1;
      }
    }
    const dur = Math.max(1, Math.round(task.durationDays));
    const ef = es + dur - 1;
    earlyStart.set(id, es);
    earlyFinish.set(id, ef);
    visiting.delete(id);
    return { es, ef };
  }

  for (const t of inputs) {
    resolveForward(t.id);
  }

  const projectDurationDays = inputs.reduce((max, t) => {
    const ef = earlyFinish.get(t.id) ?? 1;
    return Math.max(max, ef);
  }, 0);

  // Build successor adjacency list for backward pass
  const successors = new Map<string, string[]>();
  for (const t of inputs) {
    successors.set(t.id, []);
  }
  for (const t of inputs) {
    for (const predId of t.predecessors) {
      if (successors.has(predId)) {
        successors.get(predId)!.push(t.id);
      }
    }
  }

  const lateStart = new Map<string, number>();
  const lateFinish = new Map<string, number>();
  const visitingBack = new Set<string>();

  function resolveBackward(id: string): { ls: number; lf: number } {
    if (lateStart.has(id) && lateFinish.has(id)) {
      return { ls: lateStart.get(id)!, lf: lateFinish.get(id)! };
    }
    const task = byId.get(id);
    if (!task) return { ls: projectDurationDays, lf: projectDurationDays };
    if (visitingBack.has(id)) {
      return { ls: projectDurationDays, lf: projectDurationDays };
    }
    visitingBack.add(id);

    const succIds = successors.get(id) ?? [];
    let lf = projectDurationDays;
    if (succIds.length > 0) {
      lf = Math.min(
        ...succIds.map((sId) => {
          const s = resolveBackward(sId);
          return s.ls - 1;
        })
      );
    }
    const dur = Math.max(1, Math.round(task.durationDays));
    const ls = lf - dur + 1;
    lateStart.set(id, ls);
    lateFinish.set(id, lf);
    visitingBack.delete(id);
    return { ls, lf };
  }

  for (const t of inputs) {
    resolveBackward(t.id);
  }

  const computedTasks: ComputedWbsTask[] = inputs.map((t) => {
    const startDay = earlyStart.get(t.id) ?? 1;
    const finishDay = earlyFinish.get(t.id) ?? startDay + t.durationDays - 1;
    const lStart = lateStart.get(t.id) ?? startDay;
    const lFinish = lateFinish.get(t.id) ?? finishDay;
    const totalFloat = lStart - startDay;
    const isCriticalPath = totalFloat === 0;

    let scheduleVarianceDays = 0;
    if (t.actualFinishDay !== null) {
      // Negative = ahead of schedule, Positive = behind schedule (days slipped)
      scheduleVarianceDays = t.actualFinishDay - finishDay;
    } else if (t.actualStartDay !== null) {
      scheduleVarianceDays = t.actualStartDay - startDay;
    }

    return {
      ...t,
      startDay,
      finishDay,
      lateStartDay: lStart,
      lateFinishDay: lFinish,
      totalFloat,
      isCriticalPath,
      scheduleVarianceDays,
    };
  });

  const criticalPathIds = computedTasks.filter((t) => t.isCriticalPath).map((t) => t.id);

  const totalDuration = computedTasks.reduce((sum, t) => sum + Math.max(1, t.durationDays), 0);
  const weightedActual = computedTasks.reduce(
    (sum, t) => sum + Math.max(1, t.durationDays) * (t.actualProgress / 100),
    0
  );
  const overallActualProgress =
    totalDuration > 0 ? Math.round((weightedActual / totalDuration) * 100) : 0;

  return {
    tasks: computedTasks,
    projectDurationDays,
    criticalPathIds,
    overallActualProgress,
    completedCount: computedTasks.filter((t) => t.status === 'Completed').length,
    inProgressCount: computedTasks.filter((t) => t.status === 'In Progress').length,
    blockedCount: computedTasks.filter((t) => t.status === 'Blocked').length,
    notStartedCount: computedTasks.filter((t) => t.status === 'Not Started').length,
  };
}

/**
 * Formats a 1-indexed working day on a 5-day-week calendar into Week/Day label (e.g. "W1 D1").
 */
export function formatWorkingDay(day: number): string {
  const safeDay = Math.max(1, Math.round(day));
  const week = Math.floor((safeDay - 1) / 5) + 1;
  const dayInWeek = ((safeDay - 1) % 5) + 1;
  return `D${safeDay} (W${week}·D${dayInWeek})`;
}
