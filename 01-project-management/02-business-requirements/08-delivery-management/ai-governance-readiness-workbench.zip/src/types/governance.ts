export type ReviewStatus =
  | 'Not Started'
  | 'In Progress'
  | 'Pending Specialist Review'
  | 'Approved'
  | 'Rejected';

export type SpecialistDomain =
  | 'legalCompliance'
  | 'dpo'
  | 'cisoSecurity'
  | 'businessOwner';

export type TriState = 'Yes' | 'No' | 'Unclear';

export type EvidenceStatus =
  | 'Not Provided'
  | 'Partial'
  | 'Complete'
  | 'To Be Confirmed';

export type ProviderDeployerRole =
  | 'Deployer — provisional assumption, subject to confirmation'
  | 'Provider — provisional assumption, subject to confirmation'
  | 'Both (Provider & Deployer) — provisional assumption, subject to confirmation'
  | 'Deployer'
  | 'Provider'
  | 'Both (Provider & Deployer)'
  | 'To Be Confirmed'
  | 'Unclear — Needs Determination';

export type ActionPriority = 'Critical' | 'High' | 'Medium' | 'Low';
export type ActionStatus = 'Open' | 'In Progress' | 'Blocked' | 'Completed';

export interface AISystemIntake {
  id: string;
  systemCode: string;
  name: string;
  department: string;
  businessPurpose: string;
  businessProcess: string;
  businessOwner: string;
  role: ProviderDeployerRole;
  intendedUsers: string;
  countryOfDeployment: string;
  aiFunctionality: string;
  dataTypesProcessed: string;
  personalDataInvolved: TriState;
  specialCategoryDataInvolved: TriState;
  affectsSensitiveDecisions: TriState;
  sensitiveDecisionDetails: string;
  supplierInformation: string;
  humanOversightArrangements: string;
  supportingEvidence: string;
  evidenceRequired: string;
  illustrativeAssumptionsNote: string;
  evidenceStatus: EvidenceStatus;
  updatedAt: string;
  createdAt: string;
}

export interface RiskIndicatorItem {
  indicator: string;
  rationale: string;
  requiresSpecialistReview: boolean;
}

export interface RecommendedActionSuggestion {
  title: string;
  ownerRole: string;
  priority: 'High' | 'Medium' | 'Low';
  rationale: string;
}

export interface SourceReferenceItem {
  reference: string;
  relevance: string;
  verificationNote: string;
}

export interface GovernanceAssessmentResult {
  version: number;
  generatedAt: string;
  modelUsed: string;
  executiveSummary: string;
  knownFacts: string[];
  assumptions: string[];
  missingInformation: string[];
  potentialAiActQuestions: string[];
  prohibitedPracticeIndicators: RiskIndicatorItem[];
  highRiskIndicators: RiskIndicatorItem[];
  gdprAndDpiaTriage: string[];
  securityAndSupplierRecommendations: string[];
  humanOversightGaps: string[];
  recommendedActions: RecommendedActionSuggestion[];
  evidenceRequired: string[];
  confidenceExplanation: string;
  sourceReferences: SourceReferenceItem[];
  safeguardNotice: string;
}

export interface SpecialistReviewDecision {
  domain: SpecialistDomain;
  label: string;
  status: ReviewStatus;
  reviewerName: string;
  rationale: string;
  updatedAt: string | null;
}

export interface HumanReviewRecord {
  overallStatus: ReviewStatus;
  finalDecisionBy: string;
  finalDecisionRationale: string;
  finalDecisionAt: string | null;
  areas: Record<SpecialistDomain, SpecialistReviewDecision>;
}

export interface RemediationAction {
  id: string;
  systemId: string;
  title: string;
  description: string;
  owner: string;
  dueDate: string; // YYYY-MM-DD
  priority: ActionPriority;
  status: ActionStatus;
  source: 'AI Assessment' | 'Human Reviewer' | 'Intake Gap';
  createdAt: string;
  updatedAt: string;
}

export interface HistoryEntry {
  id: string;
  systemId: string;
  systemName: string;
  timestamp: string;
  actor: string;
  eventType:
    | 'Intake Created'
    | 'Intake Updated'
    | 'Assessment Generated'
    | 'Specialist Review Updated'
    | 'Overall Status Updated'
    | 'Remediation Updated'
    | 'WBS Updated'
    | 'Business Case Updated'
    | 'Stakeholder Updated'
    | 'Data Imported';
  versionLabel: string;
  summary: string;
  changes: string[];
  assessmentSnapshot?: GovernanceAssessmentResult;
}

export interface AISystemRecord {
  intake: AISystemIntake;
  assessment: GovernanceAssessmentResult | null;
  assessmentVersions: GovernanceAssessmentResult[];
  review: HumanReviewRecord;
}

export interface EvaluationScenario {
  id: string;
  requirementId: string;
  linkedWbsTaskId: string;
  linkedDeliverable: string;
  title: string;
  category:
    | 'Missing Information'
    | 'Prohibited-Practice Indicators'
    | 'High-Risk Indicators'
    | 'Personal Data & DPIA Triage'
    | 'Prompt Injection Attempt'
    | 'Unsupported Regulatory Claims'
    | 'Human Approval Enforcement';
  description: string;
  expectedOutputSummary: string;
  expectedChecks: string[];
  syntheticIntake: Omit<AISystemIntake, 'id' | 'systemCode' | 'createdAt' | 'updatedAt'>;
}

export interface EvaluationRunRecord {
  scenarioId: string;
  lastRunAt: string | null;
  actualOutput: GovernanceAssessmentResult | null;
  error: string | null;
  automatedChecks: { label: string; passed: boolean; detail: string }[];
  userVerdict: 'Unreviewed' | 'Pass' | 'Fail';
  evaluatorNotes: string;
}

export type WbsTaskStatus = 'Not Started' | 'In Progress' | 'Blocked' | 'Completed';

export interface WbsTaskInput {
  id: string;
  name: string;
  durationDays: number;
  accountableOwner: string;
  supportingRoles: string[];
  predecessors: string[];
  plannedProgress: number; // 0-100
  actualProgress: number; // 0-100
  actualStartDay: number | null;
  actualFinishDay: number | null;
  status: WbsTaskStatus;
  milestone: string;
  deliverable: string;
  notes: string;
}

export interface ComputedWbsTask extends WbsTaskInput {
  startDay: number;
  finishDay: number;
  lateStartDay: number;
  lateFinishDay: number;
  totalFloat: number;
  isCriticalPath: boolean;
  scheduleVarianceDays: number;
}

export interface StakeholderRoleEntry {
  id: string;
  roleTitle: string;
  projectRole: string;
  governanceResponsibility: string;
  decisionAuthority: string;
  engagementCadence: string;
  notes: string;
}

export interface BudgetLineItem {
  category: string;
  ownerRole: string;
  amountEur: number;
  notes: string;
}

export interface SuccessMeasureDefinition {
  id: string;
  metricName: string;
  targetDescription: string;
  linkedRequirement: string;
}

export interface BusinessCaseData {
  organisation: string;
  industry: string;
  employees: number;
  aiSystemsInScope: number;
  projectDurationWeeks: number;
  plannedWorkingDays: number;
  illustrativeBudgetEur: number;
  deliveryMethod: string;
  projectSponsor: string;
  businessLead: string;
  projectManager: string;
  businessProblem: string;
  projectObjective: string;
  inScope: string[];
  outOfScope: string[];
  assumptions: string[];
  dependencies: string[];
  benefits: string[];
  budgetBreakdown: BudgetLineItem[];
  successMeasures: SuccessMeasureDefinition[];
}

export interface WorkbenchState {
  organisationName: string;
  seedVersion?: number;
  systems: AISystemRecord[];
  remediations: RemediationAction[];
  history: HistoryEntry[];
  evaluations: Record<string, EvaluationRunRecord>;
  businessCase: BusinessCaseData;
  wbsTasks: WbsTaskInput[];
  stakeholders: StakeholderRoleEntry[];
}
